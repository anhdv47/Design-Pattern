const fs = require("fs").promises;
const path = require("path");
const process = require("process");
const { authenticate } = require("@google-cloud/local-auth");
const { google } = require("googleapis");
const port = process.env.PORT || 5000;
const app = require("express")();
const http = require("http").createServer(app);

http.listen(port, () => {
    console.log(`listening on ${port}`);
});

// If modifying these scopes, delete token.json.
const SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"];
// The file token.json stores the user's access and refresh tokens, and is
// created automatically when the authorization flow completes for the first
// time.
const TOKEN_PATH = path.join(process.cwd(), "token.json");
const CREDENTIALS_PATH = path.join(process.cwd(), "credentials.json");

/**
 * Reads previously authorized credentials from the save file.
 *
 * @return {Promise<OAuth2Client|null>}
 */
async function loadSavedCredentialsIfExist() {
    try {
        const content = await fs.readFile(TOKEN_PATH);
        const credentials = JSON.parse(content);
        return google.auth.fromJSON(credentials);
    } catch (err) {
        return null;
    }
}

/**
 * Serializes credentials to a file compatible with GoogleAUth.fromJSON.
 *
 * @param {OAuth2Client} client
 * @return {Promise<void>}
 */
async function saveCredentials(client) {
    const content = await fs.readFile(CREDENTIALS_PATH);
    const keys = JSON.parse(content);
    const key = keys.installed || keys.web;
    const payload = JSON.stringify({
        type: "authorized_user",
        client_id: key.client_id,
        client_secret: key.client_secret,
        refresh_token: client.credentials.refresh_token,
    });
    await fs.writeFile(TOKEN_PATH, payload);
}

/**
 * Load or request or authorization to call APIs.
 *
 */
async function authorize() {
    let client = await loadSavedCredentialsIfExist();
    if (client) {
        return client;
    }
    client = await authenticate({
        scopes: SCOPES,
        keyfilePath: CREDENTIALS_PATH,
    });
    if (client.credentials) {
        await saveCredentials(client);
    }
    return client;
}

// List the user's Gmail labels.
app.get("/", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.labels.list({
        userId: "me",
    });
    res.send(response.data.labels);
});

// Lists the messages in the user's mailbox.
app.get("/messages", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.list({
        userId: "me",
    });
    res.send(response.data.messages);
});

// List the messages and summaries of the user's mailbox.
app.get("/messages/summaries", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.list({
        userId: "me",
        includeSpamTrash: true,
        maxResults: 10,
    });
    const messages = response.data.messages;
    const summaries = await Promise.all(
        messages.map(async (message) => {
            const response = await gmail.users.messages.get({
                userId: "me",
                id: message.id,
                format: "metadata",
            });
            // tra ve thong tin summary nhu subject, snippet, labelIds, bcc, cc, to, from, date,
            return {
                id: message.id,
                snippet: response.data.snippet,
                subject: response.data.payload.headers.find(
                    (header) => header.name === "Subject"
                ).value,
                labelIds: response.data.labelIds,
                bcc: response.data.payload.headers.find(
                    (header) => header.name === "Bcc"
                )?.value,
                cc: response.data.payload.headers.find(
                    (header) => header.name === "Cc"
                )?.value,
                to: response.data.payload.headers.find(
                    (header) => header.name === "To"
                )?.value,
                from: response.data.payload.headers.find(
                    (header) => header.name === "From"
                )?.value,
                date: response.data.payload.headers.find(
                    (header) => header.name === "Date"
                )?.value,
            };
        })
    );
    res.send(summaries);
});

// Get a message by ID.
app.get("/message/:id", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.get({
        userId: "me",
        id: req.params.id,
    });
    res.send(response.data);
});

// Immediately and permanently deletes the specified message. This operation cannot be undone. Prefer messages.trash instead.
app.delete("/message/:id", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.delete({
        userId: "me",
        id: req.params.id,
    });
    res.send(response.data);
});

// Move a message to the trash.
app.post("/message/:id/trash", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.trash({
        userId: "me",
        id: req.params.id,
    });
    res.send(response.data);
});

// Untrash a message.
app.post("/message/:id/untrash", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.untrash({
        userId: "me",
        id: req.params.id,
    });
    res.send(response.data);
});

// Modifies the labels on the specified message.
app.post("/message/:id/modify", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.modify({
        userId: "me",
        id: req.params.id,
        resource: req.body,
    });
    res.send(response.data);
});

// Deletes many messages by message ID. Provides no guarantees that messages were not already deleted or even existed at all.
app.delete("/messages", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.batchDelete({
        userId: "me",
        resource: {
            ids: req.body.ids,
        },
    });
    res.send(response.data);
});

// Moves many messages to the trash.
app.post("/messages/trash", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.batchTrash({
        userId: "me",
        resource: {
            ids: req.body.ids,
        },
    });
    res.send(response.data);
});

// Untrashes many messages.
app.post("/messages/untrash", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.batchUntrash({
        userId: "me",
        resource: {
            ids: req.body.ids,
        },
    });
    res.send(response.data);
});

// Modifies the labels on many messages.
app.post("/messages/modify", async (req, res) => {
    const auth = await authorize();
    const gmail = google.gmail({ version: "v1", auth });
    const response = await gmail.users.messages.batchModify({
        userId: "me",
        resource: req.body,
    });
    res.send(response.data);
});
