﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace WindowsFormsApp1.Models
{
    

    public class Account
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class DecaptchaObj
    {
        public string Url { get; set; }
        public string XApiKey { get; set; }
        public string Project { get; set; }
    }
    public class DownloadXMLResult
    {
        public string InvoiceId { get; set; }
        public string XMLContent { get; set; }
        public InvoiceBotResponse DetailContent { get; set; }
    }

    public class EInvoiceTab
    {
        public int TabIndex { get; set; } = 1;
        public string TabName { get; set; }
    }
    public class ExtractToXmlResult
    {
        public string XMLContent { get; set; }
        public string HTMLContent { get; set; }
        public string FolderPath { get; set; }
    }

    /// <summary>
    /// Class này là của combobox trạng thái hóa đơn
    /// </summary>
    public class InvoiceStatus
    {
        public int Status { get; set; }
        public string StatusName { get; set; }
    }

    /// <summary>
    /// Class này là của combobox kết quả kiểm tra hóa đơn
    /// </summary>
    public class InvoiceCheckResult
    {
        public int Result { get; set; }
        public string ResultName { get; set; }
    }

    public class ProgressBarManager
    {
        private static ToolStripProgressBar _progressBar = Program.ProgressBarGlobal;

        public ProgressBarManager(ToolStripProgressBar progressBar)
        {
            _progressBar = progressBar;
        }

        public static void UpdateProgress(int completed, int total)
        {
            if (completed > total || _progressBar == null) return;
            int progressPercentage = (int)((double)completed / total * 100);
            _progressBar.Value = progressPercentage;
        }
    }


    public static class DownloadEinvoiceSetting
    {
        public static string LinkCaptcha { get; set; } = "/captcha";
        public static string LinkLogIn { get; set; } = "/security-taxpayer/authenticate";
        public static string LinkInvoice { get; set; } = "/query/apps/invoice";
        public static string LinkPurchaseInvoices { get; set; } = "/query/invoices/purchase";
        public static string LinkSoldInvoices { get; set; } = "/query/invoices/sold";
        public static string LinkExportXml { get; set; } = "/query/invoices/export-xml";
        public static string LinkExportXmlFromCashRegister { get; set; } = "/sco-query/invoices/export-xml";
        public static string LinkGetDetail { get; set; } = "/query/invoices/detail";
        public static string LinkSearch { get; set; } = "/query/guest-invoices";
        public static string LinkPurchaseInvoicesFromCashRegister { get; set; } = "/sco-query/invoices/purchase";
        public static string LinkSoldInvoicesFromCashRegister { get; set; } = "/sco-query/invoices/sold";
        public static string LinkGetDetailFromCashRegister { get; set; } = "/sco-query/invoices/detail";
        public static string LinkSearchFromCashRegister { get; set; } = "/sco-query/guest-invoices";
    }

    public class LogInRequest
    {
        public string CaptchaKey { get; set; }
        public string CaptchaText { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public class BaseTaxaxionResponse
    {
        [JsonProperty("details")]
        public string Details { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("path")]
        public string Path { get; set; }

        [JsonProperty("timestamp")]
        public string Timestamp { get; set; }
    }

    /// <summary>
    /// Token trả về khi đăng nhập thành công
    /// </summary>
    public class LogInResponse : BaseTaxaxionResponse
    {
        [JsonProperty("token")]
        public string Token { get; set; }
    }

    /// <summary>
    /// Model hứng kết quả khi giải mã captcha từ dự án Misa DeCaptcha /// </summary>
    public class CaptchaResult
    {
        [JsonProperty("captcha-text")]
        public string CaptchaText { get; set; }

    }
    /// <summary>
    /// Model trả về từ API Captcha của cơ quan thuế
    /// </summary>
    public class CaptchaResponse
    {
        public string Content { get; set; }
        public string Key { get; set; }
        public string SvgContent { get; set; }
    }

    /// <summary>
    /// Model trả về từ API Decaptcha "captcha-text":"HMYE5X"}
    //
    /// </summary>
    public class DeCaptchaResponse
    {
        [JsonProperty("captcha-text")]
        public string CaptchaText { get; set; }
        public string Key { get; set; }
    }

    public class ConnectBaseRequest
    {
        public int ConnectType { get; set; }
        public bool IsFromCashRegister { get; set; }
    }

    public class InvoiceInfoRequest : ConnectBaseRequest
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Take { get; set; } = 50;
        /// <summary>
        /// Tra cứu hóa đơn mua/bán
        /// 0: Hóa đơn mua
        /// 1: Hóa đơn bán
        /// </summary>
        public int EinvoiceTab { get; set; } = 1;

        /// <summary>
        /// Trạng thái hóa đơn
        /// </summary>
        public int InvoiceStatus { get; set; } = 0;

        /// <summary>
        /// Kết quả kiểm tra hóa đơn
        /// </summary>
        public int InvoiceCheckResult { get; set; } = -1;
        public string State { get; set; }

        /// <summary>
        /// Trạng thái hóa đơn
        /// </summary>
        public int Status { get; set; } = 0;

        public bool Unhiem { get; set; } = false;

        public bool IsPaymentOrder { get; set; } = false;
    }

    public class InvoiceListResult
    {
        public List<InvoicesResponse> Invoices { get; set; }
        public List<InvoicesResponse> InvoicesFromCashRegister { get; set; }

        public int Total
        {
            get
            {
                int total = 0;
                if (Invoices != null && Invoices.Count > 0)
                {
                    total += Invoices.FirstOrDefault().Total ?? 0;
                }
                if (InvoicesFromCashRegister != null && InvoicesFromCashRegister.Count > 0)
                {
                    total += InvoicesFromCashRegister.FirstOrDefault().Total ?? 0;
                }
                return total;
            }
        }
        public List<HoaDon> AllInvoices
        {
            get
            {
                List<HoaDon> invoices = new List<HoaDon>();
                if (Invoices != null && Invoices.Count > 0)
                {
                    Invoices.ForEach(x =>
                    {
                        invoices.AddRange(x.Datas);
                    });

                }
                if (InvoicesFromCashRegister != null && InvoicesFromCashRegister.Count > 0)
                {
                    InvoicesFromCashRegister.ForEach(x =>
                    {
                        invoices.AddRange(x.Datas);
                    });
                }
                return invoices;
            }
        }
    }

    public class InvoicesResponse : BaseTaxaxionResponse
    {
        [JsonProperty("datas")]
        public List<HoaDon> Datas { get; set; }

        [JsonProperty("size")]
        public int? Size { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("total")]
        public int? Total { get; set; }
    }

    public class HoaDon : BaseTaxaxionResponse
    {
        /// <summary>
        /// Mã định danh hoá đơn trên hệ thống core
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// Phiên bản
        /// </summary>
        [JsonProperty("pban")]
        public string PBan { get; set; }

        /// <summary>
        /// Là hóa đơn ủy nhiệm?
        /// </summary>
        [JsonProperty("unhiem")]
        public int? UNhiem { get; set; }

        /// <summary>
        /// Mã số thuế đơn vị nhận ủy nhiệm lập hóa đơn
        /// </summary>
        [JsonProperty("mstdvnunlhdon")]
        public string MstUNhiem { get; set; }

        /// <summary>
        /// Tên đơn vị nhận ủy nhiệm lập hóa đơn
        /// </summary>
        /// </summary>
        [JsonProperty("tdvnunlhdon")]
        public string TenUNhiem { get; set; }

        /// <summary>
        /// Địa chỉ đơn vị nhận ủy nhiệm lập hóa đơn
        /// </summary>
        /// </summary>
        [JsonProperty("dcdvnunlhdon")]
        public string DChiUNhiem { get; set; }

        /// <summary>
        /// Hình thức hóa đơn
        /// </summary>
        /// </summary>
        [JsonProperty("hthdon")]
        public int? HThucHDon { get; set; }

        /// <summary>
        /// Loại hóa đơn/Loại áp dụng hóa đơn
        /// </summary>
        /// </summary>
        [JsonProperty("ladhddt")]
        public int? LoaiHDon { get; set; }

        /// <summary>
        /// Ký hiệu mẫu số hóa đơn
        /// </summary>
        [JsonProperty("khmshdon")]
        public int? KyHieuMSoHDon { get; set; }

        /// <summary>
        /// Tên loại hóa đơn
        /// </summary>
        [JsonProperty("tlhdon")]
        public string TenLoaiHDon { get; set; }

        /// <summary>
        /// Mã hóa đơn
        /// </summary>
        [JsonProperty("hdon")]
        public string MaHDon { get; set; }

        /// <summary>
        /// Ký hiệu hóa đơn
        /// </summary>
        [JsonProperty("khhdon")]
        public string KyHieuHDon { get; set; }

        /// <summary>
        /// Số hóa đơn
        /// </summary>
        [JsonProperty("shdon")]
        public string SoHDon { get; set; }

        /// <summary>
        /// Kiểu hóa đơn
        /// </summary>
        [JsonProperty("khdon")]
        public int? KieuHDon { get; set; }

        /// <summary>
        /// Hóa đơn được ủy nhiệm lập
        /// </summary>
        [JsonProperty("hddunlap")]
        public int? UNhiemLap { get; set; } //1 Hóa đơn được uỷ nhiệm lập

        /// <summary>
        /// Tên hóa đơn
        /// </summary>
        [JsonProperty("thdon")]
        public string TenHDon { get; set; }

        /// <summary>
        /// Số bảng kê (Số của bảng kê các loại hàng hóa, dịch vụ đã bán kèm theo hóa đơn)
        /// Đính kèm số bảng kê …
        /// </summary>
        [JsonProperty("dksbke")]
        public string SoBangKe { get; set; }

        /// <summary>
        /// Ngày bảng kê (Ngày của bảng kê các loại hàng hóa, dịch vụ đã bán kèm theo hóa đơn)
        /// Đính kèm bảng kê lập ngày ….
        /// </summary>
        [JsonProperty("dknlbke")]
        public DateTime? NgayBangKe { get; set; }

        /// <summary>
        /// Tính chất hoá đơn
        /// </summary>
        [JsonProperty("tchat")]
        public int? TChat { get; set; }

        /// <summary>
        /// Loại hóa đơn gốc (Loại áp dụng hóa đơn của HĐ gốc)
        /// </summary>
        [JsonProperty("lhdgoc")]
        public int? LoaiHDonGoc { get; set; }

        /// <summary>
        /// Ký hiệu mẫu số hóa đơn gốc (Ký hiệu mẫu số hóa đơn bị thay thế/điều chỉnh)
        /// </summary>
        [JsonProperty("khmshdgoc")]
        public string KyHieuMSoHDonGoc { get; set; }

        /// <summary>
        /// Ký hiệu hóa đơn gốc (Ký hiệu hóa đơn bị thay thế/điều chỉnh)
        /// </summary>
        [JsonProperty("khhdgoc")]
        public string KyHieuHDonGoc { get; set; }

        /// <summary>
        /// Số hóa đơn gốc (Số hóa đơn bị thay thế/điều chỉnh)
        /// </summary>
        [JsonProperty("shdgoc")]
        public string SoHDonGoc { get; set; }

        /// <summary>
        /// Ghi chú hóa đơn gốc
        /// </summary>
        [JsonProperty("gchdgoc")]
        public string GhiChuHDonGoc { get; set; }

        /// <summary>
        /// Thời điểm lập hóa đơn gốc
        /// </summary>
        [JsonProperty("tdlhdgoc")]
        public DateTime? NgayHDonGoc { get; set; }

        /// <summary>
        /// Hình thức thanh toán
        /// </summary>
        [JsonProperty("htttoan")]
        public int? HThucTT { get; set; }

        /// <summary>
        /// Tên hình thức thanh toán
        /// </summary>
        [JsonProperty("thtttoan")]
        public string TenHThucTT { get; set; }

        /// <summary>
        /// Đơn vị tiền tệ
        /// </summary>
        [JsonProperty("dvtte")]
        public string DonViTienTe { get; set; }

        /// <summary>
        /// Tỷ giá
        /// </summary>
        [JsonProperty("tgia")]
        public double? TyGia { get; set; }

        /// <summary>
        /// Thông tin khác về dữ liệu hoá đơn
        /// </summary>
        [JsonProperty("ttkhac")]
        public List<TTinKhac> TTinKhac { get; set; }

        /// <summary>
        /// Mã số thuế tổ chức cung cấp giải pháp hóa đơn điện tử
        /// </summary>
        [JsonProperty("msttcgp")]
        public string MSTNhaCungCap { get; set; }

        /// <summary>
        /// Mã số thuế người bán/người xuất hàng
        /// </summary>
        [JsonProperty("nbmst")]
        public string MSTNBan { get; set; }

        /// <summary>
        /// Tên người bán/Tên người xuất hàng/Tên tổ chức, cá nhân
        /// </summary>
        [JsonProperty("nbten")]
        public string TenNBan { get; set; }

        /// <summary>
        /// Họ và tên người xuất hàng
        /// </summary>
        [JsonProperty("nbtnban")]
        public string TenNgXuatHang { get; set; }

        /// <summary>
        /// Mã đơn vị quan hệ ngân sách (Mã số đơn vị có quan hệ với ngân sách của đơn vị bán tài sản công)
        /// </summary>
        [JsonProperty("nbmdvqhnsach")]
        public string MaDviQheNganSachNBan { get; set; }

        /// <summary>
        /// Địa chỉ trụ sở của người bán/người xuất hàng
        /// </summary>
        [JsonProperty("nbdchi")]
        public string DChiNBan { get; set; }

        /// <summary>
        /// Số điện thoại người bán
        /// </summary>
        [JsonProperty("nbsdthoai")]
        public string SDTNBan { get; set; }

        /// <summary>
        /// Địa chỉ thư điện tử của người bán
        /// </summary>
        [JsonProperty("nbdctdtu")]
        public string EmailNBan { get; set; }

        /// <summary>
        /// Fax người bán
        /// </summary>
        [JsonProperty("nbfax")]
        public string FaxNBan { get; set; }

        /// <summary>
        /// Website người bán
        /// </summary>
        [JsonProperty("nbwebsite")]
        public string WebsiteNBan { get; set; }

        /// <summary>
        /// Số tài khoản người bán
        /// </summary>
        [JsonProperty("nbstkhoan")]
        public string SoTKNBan { get; set; }

        /// <summary>
        /// Tên ngân hàng người bán
        /// </summary>
        [JsonProperty("nbtnhang")]
        public string NganHangNBan { get; set; }

        /// <summary>
        /// Thông tin khác về người bán
        /// </summary>
        [JsonProperty("nbttkhac")]
        public List<TTinKhac> TTinKhacNBan { get; set; }

        /// <summary>
        /// Lệnh điều động nội bộ
        /// </summary>
        [JsonProperty("nblddnbo")]
        public string LenhDieuDong { get; set; }

        /// <summary>
        /// Tên người vận chuyển
        /// </summary>
        [JsonProperty("nbtnvchuyen")]
        public string NgVanChuyen { get; set; }

        /// <summary>
        /// Phương tiện vận chuyển
        /// </summary>
        [JsonProperty("nbptvchuyen")]
        public string PhuongTienVanChuyen { get; set; }

        /// <summary>
        /// Hợp đồng vận chuyển
        /// </summary>
        [JsonProperty("nbhdso")]
        public string HopDongVanChuyen { get; set; }

        /// <summary>
        /// Hợp đồng kinh tế số
        /// </summary>
        [JsonProperty("nbhdktso")]
        public string HopDongKinhTe { get; set; }

        /// <summary>
        /// Hợp đồng kinh tế ngày
        /// </summary>
        [JsonProperty("nbhdktngay")]
        public DateTime? NgayHopDongKinhTe { get; set; }

        /// <summary>
        /// Số quyết định (Số quyết định bán tài sản)
        /// </summary>
        [JsonProperty("nbsqdinh")]
        public string SoQDinh { get; set; }

        /// <summary>
        /// Ngày cấp quyết định (Ngày cấp quyết định bán tài sản)
        /// </summary>
        [JsonProperty("nbncqdinh")]
        public DateTime? NgayCapQDinh { get; set; }

        /// <summary>
        /// Cơ quan cấp quyết định (Cơ quan cấp quyết định bán tài sản)
        /// </summary>
        [JsonProperty("nbcqcqdinh")]
        public string CoQuanQDinh { get; set; }

        /// <summary>
        /// Hình thức bán
        /// </summary>
        [JsonProperty("nbhtban")]
        public string HThucBan { get; set; }

        /// <summary>
        /// Chữ ký số người bán
        /// </summary>
        [JsonProperty("nbcks")]
        public string CKSNBan { get; set; }

        /// <summary>
        /// Mã khách hàng
        /// </summary>
        [JsonProperty("mkhang")]
        public string MaKH { get; set; }

        /// <summary>
        /// Mã số thuế người mua/Mã số thuế người nhận hàng (MST NNT)
        /// </summary>
        [JsonProperty("nmmst")]
        public string MSTNMua { get; set; }

        /// <summary>
        /// Tên NNT
        /// </summary>
        [JsonProperty("nmten")]
        public string TenNNT { get; set; }

        /// <summary>
        /// Tên người mua/Tên người nhận hàng
        /// </summary>
        [JsonProperty("nmtnmua")]
        public string TenNMua { get; set; }

        /// <summary>
        /// Mã đơn vị quan hệ ngân sách (Mã số đơn vị có quan hệ với ngân sách của đơn vị)
        /// </summary>
        [JsonProperty("nmmdvqhnsach")]
        public string MaDviQheNganSachNMua { get; set; }

        /// <summary>
        /// Địa chỉ người mua/Địa chỉ kho nhận hàng
        /// </summary>
        [JsonProperty("nmdchi")]
        public string DChiNMua { get; set; }

        /// <summary>
        /// Số điện thoại người mua
        /// </summary>
        [JsonProperty("nmsdthoai")]
        public string SDTNMua { get; set; }

        /// <summary>
        /// Địa chỉ thư điện tử của người mua
        /// </summary>
        [JsonProperty("nmdctdtu")]
        public string EmailNMua { get; set; }

        /// <summary>
        /// Số CMND/ Hộ chiếu
        /// </summary>
        [JsonProperty("nmcmnd")]
        public string CMNDNMua { get; set; }

        /// <summary>
        /// Căn cước công dân người mua
        /// </summary>
        [JsonProperty("nmcccd")]
        public string CCCDanNMua { get; set; }

        /// <summary>
        /// Số tài khoản người mua
        /// </summary>
        [JsonProperty("nmstkhoan")]
        public string SoTKNMua { get; set; }

        /// <summary>
        /// Tên ngân hàng người mua
        /// </summary>
        [JsonProperty("nmtnhang")]
        public string NganHangNMua { get; set; }

        /// <summary>
        /// Thông tin khác về người mua
        /// </summary>
        [JsonProperty("nmttkhac")]
        public List<TTinKhac> TTinKhacNMua { get; set; }

        /// <summary>
        /// Chữ ký số người mua
        /// </summary>
        [JsonProperty("nmcks")]
        public string CKSNMua { get; set; }

        /// <summary>
        /// Địa điểm vận chuyển hàng đến
        /// </summary>
        [JsonProperty("nmddvchden")]
        public string DChiNhanHang { get; set; }

        /// <summary>
        /// Thời gian vận chuyển hàng đến từ
        /// </summary>
        [JsonProperty("nmtgvchdtu")]
        public DateTime? ThoiGianHangDenTu { get; set; }

        /// <summary>
        /// Thời gian vận chuyển hàng đến đến
        /// </summary>
        [JsonProperty("nmtgvchdden")]
        public DateTime? ThoiGianHangDenDen { get; set; }

        /// <summary>
        /// Số hộ chiếu (Số hộ chiếu/Giấy tờ nhập xuất cảnh)
        /// </summary>
        [JsonProperty("shchieu")]
        public string SoHoChieu { get; set; }

        /// <summary>
        /// Ngày cấp hộ chiếu (Ngày cấp hộ chiếu/Giấy tờ nhập xuất cảnh)
        /// </summary>
        [JsonProperty("nchchieu")]
        public DateTime? NgayCapHoChieu { get; set; }

        /// <summary>
        /// Ngày hết hạn hộ chiếu (Ngày hết hạn hộ chiếu/Giấy tờ nhập xuất cảnh)
        /// </summary>
        [JsonProperty("nhhhchieu")]
        public DateTime? NgayHetHanCapHoChieu { get; set; }

        /// <summary>
        /// Quốc tịch
        /// </summary>
        [JsonProperty("qtich")]
        public string QuocTich { get; set; }

        /// <summary>
        /// Tổng hợp theo từng loại thuế suất
        /// </summary>
        [JsonProperty("thttltsuat")]
        public List<ThueSuat> TongHopThueSuat { get; set; }

        /// <summary>
        /// GTGT: Tổng tiền chưa thuế
        /// Hóa đơn bán hàng: Tổng tiền hàng hóa, dịch vụ
        /// </summary>
        [JsonProperty("tgtcthue")]
        public double? TTienChuaThue { get; set; }

        /// <summary>
        /// Tổng tiền thuế
        /// </summary>
        [JsonProperty("tgtthue")]
        public double? TTienThue { get; set; }

        /// <summary>
        /// Tổng hợp theo từng loại phí
        /// </summary>
        [JsonProperty("thttlphi")]
        public List<LePhi> TongHopPhi { get; set; }

        /// <summary>
        /// Tổng tiền phí
        /// </summary>
        [JsonProperty("tgtphi")]
        public double? TienPhi { get; set; }

        /// <summary>
        /// Tổng tiền chiết khấu thương mại
        /// </summary>
        [JsonProperty("ttcktmai")]
        public double? TienCKhauTMai { get; set; }

        /// <summary>
        /// Tổng tiền thanh toán bằng số
        /// </summary>
        [JsonProperty("tgtttbso")]
        public double? TTienTToan { get; set; }

        /// <summary>
        /// Tổng tiền thanh toán bằng chữ
        /// </summary>
        [JsonProperty("tgtttbchu")]
        public string TTienTToanChu { get; set; }

        /// <summary>
        /// Thông tin thanh toán khác
        /// </summary>
        [JsonProperty("ttttkhac")]
        public List<TTinKhac> TTinTToanKhac { get; set; }

        /// <summary>
        /// Thông tin khác về hoá đơn
        /// </summary>
        [JsonProperty("cttkhac")]
        public List<TTinKhac> TTinKhacHDon { get; set; }

        /// <summary>
        /// Ngày ký
        /// </summary>
        [JsonProperty("nky")]
        public DateTime? NgayKy { get; set; }

        /// <summary>
        /// Mã của cơ quan thuế quản lý
        /// </summary>
        [JsonProperty("cqt")]
        public string MaCoQuanThue { get; set; }

        /// <summary>
        /// Trạng thái hóa đơn
        /// </summary>
        [JsonProperty("tthai")]
        public int? TThai { get; set; }

        /// <summary>
        /// Trạng thái xử lý hoá đơn trên hệ thống
        /// </summary>
        [JsonProperty("ttxly")]
        public int? TThaiXuLy { get; set; }

        /// <summary>
        /// Các nội dung phản hồi trạng thái xử lí
        /// </summary>
        [JsonProperty("pdndungs")]
        public List<string> PdNdungs { get; set; }

        /// <summary>
        /// Ngày tạo
        /// </summary>
        [JsonProperty("ntao")]
        public DateTime? NgayTao { get; set; }

        /// <summary>
        /// Ngày cập nhật
        /// </summary>
        [JsonProperty("ncnhat")]
        public DateTime? NgayCapNhat { get; set; }

        /// <summary>
        /// Người cập nhật
        /// </summary>
        [JsonProperty("ngcnhat")]
        public string NguoiCapNhat { get; set; }

        /// <summary>
        /// Phương thức gửi tờ khai
        /// </summary>
        [JsonProperty("ptgui")]
        public int? PThucGui { get; set; }

        /// <summary>
        /// MST TVAN/DNKNTT
        /// </summary>
        [JsonProperty("tvandnkntt")]
        public string MSTTVAN { get; set; }

        /// <summary>
        /// Mã thông điệp tham chiếu
        /// </summary>
        [JsonProperty("mtdtchieu")]
        public string MaThamChieu { get; set; }

        /// <summary>
        /// Mã định danh hồ sơ gốc của hóa đơn
        /// </summary>
        [JsonProperty("hsgoc")]
        public string MaDinhDanh { get; set; }

        /// <summary>
        /// Ngày tiếp nhận
        /// </summary>
        [JsonProperty("ntnhan")]
        public DateTime? NgayTiepNhan { get; set; }

        /// <summary>
        /// Thời điểm lập hóa đơn
        /// </summary>
        [JsonProperty("tdlap")]
        public DateTime? ThoiDiemLap { get; set; }

        /// <summary>
        /// Năm và tháng lập hoá đơn, định dạng yyyyMM.
        /// Ví dụ: hoá đơn lập vào ngày 22/05/2018 thì thlap = 201805
        /// </summary>
        [JsonProperty("thlap")]
        public int? NamThangLap { get; set; }

        /// <summary>
        /// Trạng thái thông báo
        /// </summary>
        [JsonProperty("tttbao")]
        public int? TThaiTBao { get; set; }

        /// <summary>
        /// Ngày cấp mã
        /// </summary>
        [JsonProperty("ncma")]
        public DateTime? NgayCapMa { get; set; }

        /// <summary>
        /// Mã hóa đơn điện tử
        /// </summary>
        [JsonProperty("mhdon")]
        public string MaHDonDTu { get; set; }

        /// <summary>
        /// Chữ ký số của cơ quan thuế
        /// </summary>
        [JsonProperty("cqtcks")]
        public string CKSCQThue { get; set; }

        /// <summary>
        /// Mã định danh hồ sơ gốc của hóa đơn sau khi cấp mã
        /// </summary>
        [JsonProperty("hsgcma")]
        public string MaDinhDanhSauCapMa { get; set; }

        /// <summary>
        /// Mã thông điệp
        /// </summary>
        [JsonProperty("mtdiep")]
        public string MaTDiep { get; set; }

        /// <summary>
        /// Mã định danh của thông báo 01/TB-KTDL
        /// </summary>
        [JsonProperty("idtbao")]
        public string MaDinhDanhTBao { get; set; }

        /// <summary>
        /// Mã định danh thông báo hủy giải trình đã hủy hóa đơn
        /// </summary>
        [JsonProperty("idtbhgtrinh")]
        public string MaDinhDanhTBaoHuyGTrinh { get; set; }

        /// <summary>
        /// Ngày thông báo hủy giải trình đã hủy hóa đơn
        /// </summary>
        [JsonProperty("tbhgtngay")]
        public DateTime? NgayTBaoHuyGTrinh { get; set; }

        /// <summary>
        /// Kỳ dữ liệu
        /// </summary>
        [JsonProperty("hkdlieu")]
        public string KyDLieuHuy { get; set; }

        /// <summary>
        /// Lần đầu
        /// </summary>
        [JsonProperty("hldau")]
        public int? HuyLanDau { get; set; }

        /// <summary>
        /// Bổ sung lần thứ
        /// </summary>
        [JsonProperty("hbslthu")]
        public int? HuyLanBoSung { get; set; }

        /// <summary>
        /// Số bảng tổng hợp dữ liệu (Số thứ tự)
        /// </summary>
        [JsonProperty("hsbthdlieu")]
        public int? SoThuTuTongHopHuy { get; set; }

        /// <summary>
        /// Loại kỳ dữ liệu T/Q
        /// </summary>
        [JsonProperty("hlkdlieu")]
        public string LoaiKyDLieuHuy { get; set; }

        /// <summary>
        /// Ngày lập bảng kê bị hủy
        /// </summary>
        [JsonProperty("hnlbke")]
        public DateTime? NgayBangKeHuy { get; set; }

        /// <summary>
        /// Hóa đơn bất hợp pháp
        /// </summary>
        [JsonProperty("bhphap")]
        public int? HDonBatHPhap { get; set; }

        /// <summary>
        /// Lý do hóa đơn bất hợp pháp
        /// </summary>
        [JsonProperty("bhpldo")]
        public string LyDoBatHPhap { get; set; }

        /// <summary>
        /// Cán bộ chuyển hóa đơn bất hợp pháp
        /// </summary>
        [JsonProperty("bhpcbo")]
        public string CanBoChuyenHDonBatHPhap { get; set; }

        /// <summary>
        /// Ngày chuyển hóa đơn bất hợp pháp
        /// </summary>
        [JsonProperty("bhpngay")]
        public DateTime? NgayChuyenHDonBatHPhap { get; set; }

        /// <summary>
        /// Mã hồ sơ
        /// </summary>
        [JsonProperty("mhso")]
        public string MaHoSo { get; set; }

        /// <summary>
        /// Kỳ dữ liệu
        /// </summary>
        [JsonProperty("kdlieu")]
        public string KyDLieu { get; set; }

        /// <summary>
        /// Lần đầu
        /// </summary>
        [JsonProperty("ldau")]
        public int? LanDau { get; set; }

        /// <summary>
        /// Bổ sung lần thứ
        /// </summary>
        [JsonProperty("bslthu")]
        public int? LanBoSung { get; set; }

        /// <summary>
        /// Số bảng tổng hợp dữ liệu (Số thứ tự)
        /// </summary>
        [JsonProperty("sbthdlieu")]
        public int? SoThuTuTongHop { get; set; }

        /// <summary>
        /// Loại kỳ dữ liệu T/Q
        /// </summary>
        [JsonProperty("lkdlieu")]
        public string LoaiKyDLieu { get; set; }

        /// <summary>
        /// Ngày lập bảng kê
        /// </summary>
        [JsonProperty("nlbke")]
        public DateTime? NgayLapBangKe { get; set; }

        /// <summary>
        /// Loại kỳ dữ liệu điều chỉnh
        /// </summary>
        [JsonProperty("lkdlgoc")]
        public string LoaiDLieuDChinh { get; set; }

        /// <summary>
        /// Kỳ dữ liệu điều chỉnh
        /// </summary>
        [JsonProperty("kdlgoc")]
        public string KyDLieuDChinh { get; set; }

        /// <summary>
        /// Hàng hóa dịch vụ
        /// </summary>
        [JsonProperty("hdhhdvu")]
        public List<HangHoaDVu> ChiTiets { get; set; }

        /// <summary>
        /// Các hóa đơn liên quan
        /// </summary>
        [JsonProperty("hdonLquans")]
        public List<HoaDon> HoaDonLienQuans { get; set; }

        /// <summary>
        /// Các hóa đơn thông báo sai sót
        /// </summary>
        [JsonProperty("hdtbssrses")]
        public List<HoaDonSaiSot> HoaDonThongBaoSaiSots { get; set; }
    }

    public class TTinKhac
    {
        /// <summary>
        /// Tên trường
        /// </summary>
        [JsonProperty("ttruong")]
        public string TenTruong { get; set; }

        /// <summary>
        /// Kiểu dữ liệu
        /// string: Chuỗi ký tự
        /// numeric: Số
        /// dateTime: Ngày giờ
        /// date: Ngày
        /// </summary>
        [JsonProperty("kdlieu")]
        public string KieuDLieu { get; set; }

        /// <summary>
        /// Tên trường
        /// </summary>
        [JsonProperty("dlieu")]
        public string DLieu { get; set; }
    }

    public class ThueSuat
    {
        /// <summary>
        /// Thuế suất (Thuế suất thuế GTGT)
        /// </summary>
        [JsonProperty("tsuat")]
        public string TSuat { get; set; }

        /// <summary>
        /// Thành tiền (Thành tiền chưa có thuế GTGT)
        /// </summary>
        [JsonProperty("thtien")]
        public double? ThTien { get; set; }

        /// <summary>
        /// Tiền thuế (Tiền thuế GTGT)
        /// </summary>
        [JsonProperty("tthue")]
        public double? TThue { get; set; }
    }

    public class LePhi
    {
        /// <summary>
        /// Tên loại phí
        /// </summary>
        [JsonProperty("tlphi")]
        public string TenPhi { get; set; }

        /// <summary>
        /// Tiền phí
        /// </summary>
        [JsonProperty("tphi")]
        public double? TienPhi { get; set; }
    }

    public class HangHoaDVu
    {
        /// <summary>
        /// Id của hóa đơn
        /// </summary>
        [JsonProperty("idhdon")]
        public string IdHDon { get; set; }

        /// <summary>
        /// Id của dòng hàng hóa, dịch vụ
        /// </summary>
        [JsonProperty("id")]
        public string IdHHoaDVu { get; set; }

        /// <summary>
        /// Id của dòng hàng hóa, dịch vụ
        /// </summary>
        [JsonProperty("tchat")]
        public int? TChat { get; set; }

        /// <summary>
        /// Số thứ tự
        /// </summary>
        [JsonProperty("stt")]
        public int? STT { get; set; }

        /// <summary>
        /// Mã hàng hóa, dịch vụ
        /// </summary>
        [JsonProperty("mhhdvu")]
        public string MaHHoaDVu { get; set; }

        /// <summary>
        /// Tên hàng hóa, dịch vụ
        /// </summary>
        [JsonProperty("ten")]
        public string TenHHoaDVu { get; set; }

        /// <summary>
        /// Đơn vị tính (Cái, Chiếc,…)
        /// </summary>
        [JsonProperty("dvtinh")]
        public string DViTinh { get; set; }

        /// <summary>
        /// Số lượng
        /// </summary>
        [JsonProperty("sluong")]
        public double? SoLuong { get; set; }

        /// <summary>
        /// Đơn giá
        /// </summary>
        [JsonProperty("dgia")]
        public double? DGia { get; set; }

        /// <summary>
        /// Tỷ lệ chiết khấu
        /// </summary>
        [JsonProperty("tlckhau")]
        public double? TyLeCKhau { get; set; }

        /// <summary>
        /// Số tiền chiết khấu
        /// </summary>
        [JsonProperty("stckhau")]
        public double? TienCKhau { get; set; }

        /// <summary>
        /// Thành tiền (Thành tiền chưa có thuế GTGT)
        /// </summary>
        [JsonProperty("thtien")]
        public double? ThTien { get; set; }

        /// <summary>
        /// Số tiền bằng chữ
        /// </summary>
        [JsonProperty("stbchu")]
        public string TienBangChu { get; set; }

        /// <summary>
        /// Loại thuế suất
        /// dmuc, mloai = tsuat (Trường hợp Khác sẽ lưu giá trị người dùng nhập)
        /// 0% - Thuế 0%
        /// 5% - Thuế 5%
        /// 10% - Thuế 10%
        /// KCT - Không chịu thuế
        /// KKKNT - Không kê khai, tính nộp thuế GTGT
        /// KHAC - Khác
        /// </summary>
        [JsonProperty("ltsuat")]
        public string LoaiTSuat { get; set; }

        /// <summary>
        /// Thuế suất
        /// </summary>
        [JsonProperty("tsuat")]
        public double? TSuat { get; set; }

        /// <summary>
        /// Tiền thuế (Tiền thuế GTGT)
        /// </summary>
        [JsonProperty("tthue")]
        public double? TThue { get; set; }

        /// <summary>
        /// Thành tiền có thuế (Thành tiền có thuế GTGT)
        /// </summary>
        [JsonProperty("thtcthue")]
        public double? ThTienSThue { get; set; }

        /// <summary>
        /// Thông tin khác
        /// </summary>
        [JsonProperty("ttkhac")]
        public List<TTinKhac> TTinKhac { get; set; }
    }

    public class HoaDonSaiSot
    {
        [JsonProperty("mst")]
        public string MST { get; set; }

        [JsonProperty("khhdon")]
        public string KyHieuHDonGoc { get; set; }

        [JsonProperty("khmshdon")]
        public string KyHieuMSoHDonGoc { get; set; }

        [JsonProperty("shdon")]
        public string SoHDonGoc { get; set; }

        [JsonProperty("gchu")]
        public string GhiChuHDonGoc { get; set; }

        [JsonProperty("kqtnhan")]
        public int? KetQuaNhan { get; set; }

        [JsonProperty("ldo")]
        public string LyDo { get; set; }

        [JsonProperty("loai")]
        public int? Loai { get; set; }

        [JsonProperty("ngay")]
        public DateTime? Ngay { get; set; }

        //[JsonProperty("so")]
        //public object So { get; set; }

        [JsonProperty("tctbao")]
        public int? TinhChatTB { get; set; }

        [JsonProperty("ten")]
        public string Ten { get; set; }

        [JsonProperty("tthai")]
        public int? TThai { get; set; }

        [JsonProperty("ttxly")]
        public int? TThaiXuLy { get; set; }
    }

    public class TaxaxionRequest : ConnectBaseRequest
    {
        public string MSTNBan { get; set; }

        public string TemplateNo { get; set; }

        public string Series { get; set; }

        public string InvoiceNo { get; set; }

        public decimal Amount { get; set; }

        public DateTime? InvoiceDate { get; set; }

        public string CaptchaText { get; set; }
        public string CaptchaKey { get; set; }
    }

    /// <summary>
    /// Model Item detail invoice bot
    /// </summary>
    /// <summary>
    /// Thông tin chi tiết của hóa đơn
    /// </summary>
    public class InvoiceItemInfo
    {
        public int LineNumber { get; set; }

        public string ItemCode { get; set; }

        public string ItemName { get; set; }

        public string UnitName { get; set; }

        public decimal? Quantity { get; set; }

        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// Tổng tiền hàng
        /// </summary> 
        public decimal AmountWithoutVat { get; set; }

        /// <summary>
        /// Có phải thuế khác không
        /// </summary>
        public bool IsVatOther { get; set; }

        public decimal? VatRate { get; set; }

        /// <summary>
        /// Hàng hóa, dịch vụ được giảm thuế theo NQ406 hay không
        /// </summary>
        public bool? IsTaxReduction { get; set; }

        /// <summary>
        /// Đánh dấu dòng diễn giải giảm thuế theo NQ43
        /// </summary>
        public bool? IsTaxReduction43Detail { get; set; }

        public decimal VatAmount { get; set; }

        /// <summary>
        /// Cờ đánh dấu đã tính lại tiền thuế chi tiết
        /// </summary>
        public bool IsCalVatAmount { get; set; }

        public decimal? DiscountRate { get; set; }

        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Tiền hàng. Đã bao gồm VAT và chiết khấu
        /// </summary>
        public decimal Amount { get; set; }

        public bool IsPromotion { get; set; }

        /// <summary>
        /// Ghi chú
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Hạn dùng đáp ứng cho mẫu dược
        /// </summary>
        public DateTime? ExpiredDate { get; set; }

        /// <summary>
        /// Số lô (đáp ứng cho mẫu dược)
        /// </summary>
        public string BatchNo { get; set; }

        /// <summary>
        /// Nước sản xuất 
        /// </summary>(đáp ứng cho mẫu dược)
        public string CountryOfManufacture { get; set; }

        /// <summary>
        /// Trường hỗ trợ để phục vụ theo Nghị Định 123 của chính phủ
        /// </summary>
        public List<OtherInfo> Others { get; set; }

        /// <summary>
        /// Tiền giảm trừ theo nghị quyết 406
        /// </summary>
        public decimal TaxReductionAmount { get; set; }

        /// <summary>
        /// Tiền giảm trừ theo nghị quyết 43
        /// </summary>
        public decimal TaxReductionAmount43 { get; set; }

        /// <summary>
        /// Tiền hàng hiển thị
        /// </summary>
        public decimal AmountWithoutVatDisplay
        {
            get
            {
                if (AmountWithoutVat == 0) return Amount;
                //Hàng hóa của Hóa đơn 123 thì đã bao gồm tiền chiết khấu luôn
                if (Kind != KindND123Enum.None) { return AmountWithoutVat; }
                //Nếu tồn tại cả số lượng, đơn giá
                if (Quantity.HasValue && UnitPrice.HasValue)
                {
                    var total = Quantity.Value * UnitPrice.Value;
                    //Vì có thể tiền lẻ lên số có thể bị làm tròn lên hoặc xuống, khi so sánh cho thêm sai số
                    if (total > AmountWithoutVat - NumberRatioAmount && total < AmountWithoutVat + NumberRatioAmount) { return AmountWithoutVat; }
                }
                return AmountWithoutVat + DiscountAmount;
            }
        }

        /// <summary>
        /// Sử dụng số này để tính toán độ chênh lệch của Tổng tiền so với Số lượng  * Đơn giá
        /// </summary>
        public const int NumberRatioAmount = 1;

        /// <summary>
        /// Số lượng thực nhập
        /// </summary>
        public decimal? QuantityImport { get; set; }

        /// <summary>
        /// Số lượng thực xuất
        /// </summary>
        public decimal? QuantityExport { get; set; }

        /// <summary>
        /// Thành tiền đã trừ chiết khấu
        /// </summary>
        public decimal AmountAfterDiscount
        {
            get
            {
                if (DiscountAmount <= 0) return AmountWithoutVat;
                if (AmountWithoutVat >= DiscountAmount) return AmountWithoutVat - DiscountAmount;
                return AmountWithoutVat;
            }
        }

        /// <summary>
        /// Tính chất của hóa đơn ND123
        /// </summary>
        public KindND123Enum Kind { get; set; } = KindND123Enum.None;

        /// <summary>
        /// Tính lại tiền thuế
        /// Trường hợp k lấy được dữ liệu tiền thuế từ XML thì tính lại
        ///  Tiền thuế = (Thành tiền trước thuế - chiết khấu) * Thuế suất T.GTGT
        /// </summary>
        /// <returns></returns>
        public decimal CalculatorVatAmount()
        {
            //Tính lại tiền thuế
            //Dòng hàng là hành hóa dịch vụ
            if (VatAmount == 0 && VatRate > 0 && (Kind == KindND123Enum.Info || Kind == KindND123Enum.Discount))
            {
                // Tiền thuế = (Thành tiền trước thuế - chiết khấu) * Thuế suất T.GTGT
                return (AmountWithoutVatDisplay - DiscountAmount) * VatRate.Value / 100;
            }
            return VatAmount;
        }

        /// <summary>
        /// Tổng tiền thanh toán
        /// Tổng tiền chưa thuế + tiền thuế
        /// </summary>
        /// <returns></returns>
        public decimal CalculatorTotalAmount() => (AmountWithoutVatDisplay - DiscountAmount) + CalculatorVatAmount();

        /// <summary>
        /// Có phải item lệ phí hay không
        /// </summary>
        public bool IsItemFee { get; set; }

        /// <summary>
        /// Tổng giảm trừ khác (Hóa đơn nước - NĐ 1510)
        /// </summary>
        public decimal? AmountOtherReduction { get; set; }
    }

    /// <summary>
    /// Thông tin khác
    /// </summary>
    public class OtherInfo
    {
        public string TTruong { get; set; }
        public string KDLieu { get; set; }
        public string DLieu { get; set; }
    }

    /// <summary>
    /// Thông tin thêm của ND 123
    /// </summary>
    public class ND123Info
    {
        /// <summary>
        /// Tồn tại trên tổng cục thuế hay không
        /// </summary>
        public int StatusExistTCT { get; set; }

        /// <summary>
        /// Hóa đơn này đã bỏ qua check tồn tại thuế, HĐ này đã tự động chấp nhận theo mẫu thiết lập
        /// </summary>
        public bool IsIgnoreStatusExistTCT { get; set; }

        /// <summary>
        /// Người chấp nhận tồn tại trên cơ quan thuế
        /// </summary>
        public string UserAcceptExist { get; set; }

        public int? ProcessingStatus { get; set; }

        public List<string> ReasonRejects { get; set; }

        public string ResonRejectText => ReasonRejects != null && ReasonRejects.Count > 0 ? string.Join(";", ReasonRejects) : "";

        /// <summary>
        /// Tính chất hoá đơn
        /// </summary>
        public int? Nature { get; set; } = 1;

        /// <summary>
        /// Trạng thái hóa đơn
        /// </summary>
        public int? Status { get; set; }

        /// <summary>
        /// Trạng thái hóa đơn trước đó(trạng thái gần nhất)
        /// </summary>
        public int? BeforeStatus { get; set; }

        /// <summary>
        /// Trạng thái hóa đơn có mới cập nhật hay không
        /// PBI 276867
        /// </summary>
        public bool IsChangeStatusInvoice { get; set; }

        /// <summary>
        /// Danh sách thuế suất trên hóa đơn
        /// </summary>
        public List<VatInfo> ListVat { get; set; } = new List<VatInfo>();

        /// <summary>
        /// Là hóa đơn điều chỉnh thay thế
        /// </summary>
        public bool IsAdjusted => Nature == 2 || Nature == 3;

        /// <summary>
        /// Thông tin hóa đơn liên quan nếu có
        /// </summary>
        public InvConnect InvConnect { get; set; } = new InvConnect();

        ///// <summary>
        ///// Lệnh điều động nội bộ
        ///// </summary>
        public string InternalTransferOrder { get; set; }

        /// <summary>
        /// Hợp đồng kinh tế số
        /// </summary>
        public string CommandOrder { get; set; }

        /// <summary>
        /// Ngày hợp đồng
        /// </summary>
        public DateTime? CommandOrderDate { get; set; }

        /// <summary>
        /// Ngày điều động nội bộ
        /// </summary>
        public DateTime? InternalCommandDate { get; set; }

        /// <summary>
        /// Của điều lệnh
        /// </summary>
        public string InternalCommandOwner { get; set; }

        /// <summary>
        /// Việc của điều lệnh
        /// </summary>
        public string CommandProblem { get; set; }

        /// <summary>
        /// Người xuất hàng
        /// </summary>
        public string ExportPerson { get; set; }

        /// <summary>
        /// Người nhập hàng
        /// </summary>
        public string ImportPerson { get; set; }

        /// <summary>
        /// Phương tiện vận chuyển
        /// </summary>
        public string VehicleType { get; set; }

        /// <summary>
        /// Người nhận hàng
        /// </summary>
        public string Receiver { get; set; }

        /// <summary>
        /// Tên người vận chuyển
        /// </summary>
        public string ShipperName { get; set; }

        /// <summary>
        /// Hợp đồng số(Hợp đồng vận chuyển)
        /// </summary>
        public string NumberAgreement { get; set; }

        /// <summary>
        /// Họ tên của người mua hàng
        /// </summary>
        public string BuyerFullName { get; set; }

        /// <summary>
        /// Số tài khoản của người mua
        /// </summary>
        public string BankAccountBuyer { get; set; }

        /// <summary>
        /// Số tài khoản của người bán
        /// </summary>
        public string BankAccountSeller { get; set; }

        /// <summary>
        /// Tên ngân hàng của người mua
        /// </summary>
        public string BankNameBuyer { get; set; }

        /// <summary>
        /// Tên ngân hàng của người bán
        /// </summary>
        public string BankNameSeller { get; set; }

        /// <summary>
        /// Số bảng kê
        /// </summary>
        public string DeclarationNumber { get; set; }

        /// <summary>
        /// Ngày bảng kê
        /// </summary>
        public DateTime? DeclarationDate { get; set; }

        /// <summary>
        /// Đã chạy tự động kiểm tra hóa đơn liên quan (thay thế) hay chưa
        /// </summary>
        public bool IsCheckedInvoiceReplace { get; set; }

        /// <summary>
        /// Danh sách các hóa đơn liên quan
        /// Trường dữ liệu phục vụ tính toán ngày thay đổi trạng thái HĐ Điều chỉnh PBI 276867
        /// </summary>
        public List<InvConnect> InvConnects { get; set; }

        /// <summary>
        /// Danh sách các hóa đơn thông báo sai sót
        /// Trường dữ liệu phục vụ tính toán ngày thay đổi trạng thái HĐ bị hủy PBI 276867
        /// </summary>
        public List<InvConnect> InvNotificationWrongs { get; set; }
    }

    public class VatInfo
    {
        /// <summary>
        /// Thuế suất
        /// </summary>
        public decimal? VatRate { get; set; }

        /// <summary>
        /// Tổng tiền thuế
        /// </summary>
        public decimal TotalVATAmount { get; set; }

        /// <summary>
        /// Tổng tiền chưa thuế
        /// </summary>
        public decimal TotalAmountWithoutVat { get; set; }

        /// <summary>
        /// Có phải thuế khác không
        /// </summary>
        public bool IsVatOther { get; set; }
    }

    public class InvConnect
    {
        /// <summary>
        /// Mẫu số
        /// </summary>
        public string TemplateNo { get; set; }

        /// <summary>
        /// Ký hiệu
        /// </summary>
        public string Series { get; set; }

        /// <summary>
        /// Số hóa đơn
        /// </summary>
        public string InvoiceNo { get; set; }

        /// <summary>
        /// Ngày hóa đơn
        /// </summary>
        public DateTime? InvoiceDate { get; set; }

        /// <summary>
        /// Ghi chú
        /// </summary>
        public string Noted { get; set; }

        /// <summary>
        /// Ngày thay đổi
        /// </summary>
        public DateTime? ChangeDate { get; set; }

        /// <summary>
        /// Lý do
        /// </summary>
        public string Reason { get; set; }

        /// <summary>
        /// Loại
        /// </summary>
        public int? Type { get; set; }

        /// <summary>
        /// Tính chất thông báo
        /// </summary>
        public int NotifyNature { get; set; }

        /// <summary>
        /// Tên thông báo
        /// </summary>
        public string NotifyName { get; set; }

        /// <summary>
        /// Trạng thái hóa đơn
        /// </summary>
        public int? StatusInvoice { get; set; }

        /// <summary>
        /// Trạng thái xử lý
        /// </summary>
        public int? StatusInvoiceProcess { get; set; }

        public bool IsHasInvoiceInfo()
        {
            return !string.IsNullOrEmpty(TemplateNo) || !string.IsNullOrEmpty(InvoiceNo) || !string.IsNullOrEmpty(Series);
        }
    }

    /// <summary>
    /// Model gửi lên con kế toán để cập nhật trạng thái hóa đơn
    /// </summary>
    public class InvoiceBotResponse : BaseInvoiceInfo
    {
        public int PostedStatus { get; set; }

        public DateTime? AccountingDate { get; set; } // Ngày hạch toán

        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        public string InvConnect { get; set; }

        public int? ProcessingStatus { get; set; }

        public bool IsInvoiceFinal { get; set; } = false;

        /// <summary>
        /// Là hóa đơn đầu vào hày không? không thì là đầu ra
        /// (sử dụng với luồng đồng bộ cho đối chiếu)
        /// </summary>
        public bool? IsInputInvoice { get; set; }
    }

    /// <summary>
    /// Danh sách hóa đơn từ trang hóa đơn điện tử gửi lên kế toán
    /// </summary>
    public class TaxAuthoritySyncMaster
    {
        /// <summary>
        /// Tổng số hóa đơn lấy về được
        /// </summary>
        public int TotalCrawl { get; set; }
        /// <summary>
        /// Tổng total thực tế trên danh sách
        /// </summary>
        public int TotalResponse { get; set; }
        /// <summary>
        /// Ngày đồng bộ
        /// </summary>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Mã số thuế công ty
        /// </summary>
        public string TaxCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string SubscriberId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string OrganizationId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// Danh sách hóa đơn
        /// </summary>
        public List<InvoiceBotResponse> Invoices { get; set; }
    }
    public class FeesInfo
    {
        /// <summary>
        /// Tên loại phí
        /// </summary>
        public string TLPhi { get; set; }

        /// <summary>
        /// Tiền phí
        /// </summary>
        public decimal? TPhi { get; set; }
    }
    public enum InvoiceCodeStatus
    {
        None = 1,
        /// <summary>
        /// Hóa đơn có mã
        /// </summary>
        WithCode = 2,
        /// <summary>
        /// Hóa đơn không mã
        /// </summary>
        WithoutCode = 3
    }

    /// <summary>
    /// Các mẫu hóa đơn cần custom lại mẫu
    /// </summary>
    public enum InvoiceCustomTemplate
    {
        /// <summary>
        /// Mẫu bình thường
        /// </summary>
        None = 0,

        /// <summary>
        /// Mẫu biên lai, lệ phí hàng hải
        /// </summary>
        InvoiceSeaFee = 1,

        /// <summary>
        /// Mẫu hóa đơn nước Bình Định
        /// </summary>
        InvoiceWaterBĐ = 2,

        /// <summary>
        /// Mẫu hóa đơn cho thuê tài chính CHAILEASE
        /// </summary>
        FinancialLeasing = 3,

        /// <summary>
        /// Mẫu hóa đơn 123 PHiếu xuất kho hàng gửi đại lý
        /// </summary>
        AgentWarehouseExport = 4,

        /// <summary>
        /// Mẫu hóa đơn 123 Phiếu xuất kho kiêm vận chuyển nội bộ
        /// </summary>
        InternalWarehouseExport = 5,

        /// <summary>
        /// Mẫu hóa đơn 123 Hóa đơn bán hàng
        /// </summary>
        InvoiceSales = 6,

        /// <summary>
        /// Mẫu hóa đơn 123 hóa đơn GTGT
        /// </summary>
        Invoice123 = 7
    }

    /// <summary>
    /// Enum thể hiện trạng thái hóa đơn
    /// Thêm Attribute để khi serialize thì sẽ serialize ra tên Enum dạng String, để có nhiều meaning với user hơn
    /// </summary>   
    public enum InvoiceInfoStatusFlags
    {
        /// <summary>
        /// Tất cả
        /// </summary>
        All = 0,
        /// <summary>
        /// Hóa đơn đang chờ kiểm tra
        /// </summary>
        WaitChecking = 1,
        /// <summary>
        /// Hóa đơn hợp lệ
        /// </summary>
        Valid = 2,
        /// <summary>
        /// Hóa đơn không hợp lệ
        /// </summary>
        Invalid = 16,
        /// <summary>
        /// Hóa đơn chưa thực hiện kiểm tra xong hết các chỉ tiêu
        /// </summary>
        Uncompleted = 24,
        /// <summary>
        /// Hóa đơn nháp
        /// </summary>
        InvoiceDraft = 8,
        /// <summary>
        /// Cờ chỉ dùng để lọc hóa đơn không có bản thể hiện pdf
        /// </summary>
        NoHasPdf = 999,
        /// <summary>
        /// Cờ dùng lọc hóa đơn không có file xml
        /// </summary>
        NoHasXml = 998,
        /// <summary>
        /// Cờ dùng lọc hóa đơn có file xml
        /// </summary>
        HasXml = 997,
    }

    public class ActionInfor
    {
        /// <summary>
        /// ID của lệnh
        /// </summary>
        public string ActionID { get; set; }
        /// <summary>
        /// Loại lệnh
        /// </summary>
        public int ActionType { get; set; }
        /// <summary>
        /// Tham số
        /// </summary>
        public string Data { get; set; }
    }

    public class ViewInvoiceFromTaxAuthority : BaseReceiveMessageFromAccounting
    {
        public string SellerTaxCode { get; set; }
        public string Series { get; set; }
        public string InvoiceNo { get; set; }
        public string TemplateNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public bool IsViewFromInputInvoice { get; set; }
    }

    public enum TThaiHDonEnum
    {
        All = 0,
        Goc = 1, // Hóa đơn gốc
        ThayThe = 2, // Hóa đơn thay thế
        DieuChinh = 3, // Hóa đơn điều chỉnh
        DaThayThe = 4, // Hóa đơn đã bị thay thế
        DaDieuChinh = 5, // Hóa đơn đã bị điều chỉnh
        Xoa = 6, // Hóa đơn đã bị xóa bỏ/hủy bỏ
        Unknown = 7 // Hóa đơn chưa xác định
    }

    public enum KyHieuMauSoEnum
    {
        GTGT = 1, //Hóa đơn giá trị gia tăng
        BanHang = 2, //Hóa đơn bán hàng
        TSanCong = 3, // Hóa đơn bán tài sản công
        DTruQuocGia = 4, //Hóa đơn bán hàng dự trữ quốc gia
        Khac = 5, //Hóa đơn khác
        ChungTuNhuHDon = 6 //Các chứng từ được in, phát hành, sử dụng và quản lý như hóa đơn
    }

    public class BaseReceiveMessageFromAccounting
    {
        /// <summary>
        /// Token để thực hiện chức năng
        /// </summary>
        public string Authorization { get; set; }
        /// <summary>
        /// Thông tin DB để cập nhật
        /// </summary>
        public string XMISAContext { get; set; }
        /// <summary>
        /// Mã số thuế doanh nghiệp
        /// </summary>
        public string TaxCode { get; set; }
        /// <summary>
        /// Tài khoản hóa đơn điện tử
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// Mật khẩu
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string SubscriberId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string OrganizationId { get; set; }
    }

    public class RequestSyncTaxAuthority : BaseReceiveMessageFromAccounting
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        /// <summary>
        /// Có phải đồng bộ từ hóa đơn đầu vào hay không
        /// nếu không thì là đồng bộ từ hóa đơn đầu ra
        /// </summary>
        public bool IsSyncFromInputInvoice { get; set; }

        /// <summary>
        /// Có lấy hóa đơn ủy nhiệm không
        /// </summary>
        public bool IsPaymentOrder { get; set; } = false;
        /// <summary>
        /// API call back lại kế toán
        /// </summary>
        public string APISyncCallback { get; set; }
        /// <summary>
        /// Danh sach hoa don ..
        /// </summary>
        public List<InvoiceExists> ListInvoiceExists { get; set; }
    }

    public class InvoiceExists
    {
        public string InvoiceId { get; set; }
        public bool HasItems { get; set; }
    }

    public enum KindND123Enum
    {
        None = 0,
        /// <summary>
        /// Tính chất 1 là HDDV
        /// </summary>
        Info = 1,
        /// <summary>
        /// Tính chất 2 là khuyến mãi
        /// </summary>
        Promotion = 2,
        /// <summary>
        /// Tính chất 3: CKTM trong trường hợp muốn thể hiện thông tin CK theo dòng
        /// </summary>
        Discount = 3,
        /// <summary>
        /// Tính chất 4: Ghi chú diễn giải
        /// </summary>
        Noted = 4
    }


    public class BaseInvoiceInfo
    {
        #region Properties
        /// <summary>
        /// Id của giao dịch
        /// </summary>
        public string TransId { get; set; }

        /// <summary>
        /// Mã hóa đơn
        /// </summary>
        public string InvoiceId { get; set; }

        /// <summary>
        /// Mã đơn vị mua tài nguyên
        /// </summary>
        public string SubscriberId { get; set; }

        /// <summary>
        /// Id đơn vị của hóa đơn
        /// </summary>
        public string OrgId { get; set; }

        /// <summary>
        /// Mã số thuế người bán
        /// </summary>
        public string SellerTaxCode { get; set; }

        /// <summary>
        /// Tên người bán
        /// </summary>
        public string SellerName { get; set; }

        /// <summary>
        /// Địa chỉ người bán
        /// </summary>
        public string SellerAddress { get; set; }

        /// <summary>
        /// Số điện thoại nhà cung cấp
        /// </summary>
        public string SellerPhoneNumber { get; set; }

        /// <summary>
        /// Số CCCD người mua
        /// </summary>
        public string BuyerNoCitizenIdentityCard { get; set; }

        /// <summary>
        /// Mã số thuế người mua
        /// </summary>
        public string BuyerTaxCode { get; set; }

        /// <summary>
        /// Tên người mua
        /// </summary>
        public string BuyerName { get; set; }

        /// <summary>
        /// Địa chỉ người mua
        /// </summary>
        public string BuyerAddress { get; set; }

        /// <summary>
        /// Mã người mua
        /// </summary>
        public string BuyerCode { get; set; }

        /// <summary>
        /// Số điện thoại người mua
        /// </summary>
        public string BuyerPhoneNumber { get; set; }

        /// <summary>
        /// thông tin khác của thông tin chung của NĐ123
        /// </summary>
        public List<OtherInfo> CommonOthers { get; set; }

        /// <summary>
        /// Có phải hóa đơn bán hàng hay không
        /// </summary>
        public bool IsInvoiceSale => !string.IsNullOrEmpty(TemplateNo) && (TemplateNo.Contains("02GTTT") || (IsInvoice123 && TemplateNo.Equals("2")));

        /// <summary>
        /// Mẫu số
        /// </summary>
        public string TemplateNo { get; set; }

        /// <summary>
        /// Ký hiệu
        /// </summary>
        public string Series { get; set; }

        /// <summary>
        /// Số hóa đơn
        /// </summary>         
        public string InvoiceNo { get; set; }

        /// <summary>
        /// Ngày hóa đơn
        /// </summary>
        public DateTime InvoiceDate { get; set; }

        /// <summary>
        /// Ngày ký hóa đơn
        /// </summary>
        public DateTime? SignedDate { get; set; }

        /// <summary>
        /// Ngày cấp mã
        /// </summary>
        public DateTime? IssueDate { get; set; }

        /// <summary>
        /// Ngày thông báo hủy/ giải trình hóa đơn
        /// </summary>
        public DateTime? ChangeStatusInvoiceDate { get; set; }

        /// <summary>
        /// Phương thức thanh toán
        /// </summary>
        public string PaymentMethod { get; set; }

        /// <summary>
        /// Mã loại tiền
        /// </summary>
        private string _ccyCode = null;

        public string CcyCode
        {
            get
            {
                return string.IsNullOrEmpty(_ccyCode) ? "VND" : _ccyCode;
            }
            set
            {
                _ccyCode = value;
            }
        }

        /// <summary>
        /// Tỷ giá hối đoái
        /// </summary>
        public decimal? ExchangeRate { get; set; }

        /// <summary>
        /// Sử dụng chuẩn hóa tỉ lệ ExchangeRate
        /// </summary>
        public string ExchangeRateStandard
        {
            get
            {
                if (ExchangeRate == null || ExchangeRate == 0) { return "1"; }
                return ExchangeRate.Value == (long)ExchangeRate.Value ? $"{Math.Round(ExchangeRate.Value, 0)}" : $"{ExchangeRate.Value}";
            }
        }

        /// <summary>
        /// Tổng tiền chưa thuế
        /// </summary>
        public decimal TotalAmountWithoutVat { get; set; }

        /// <summary>
        /// Thuế suất
        /// </summary>
        public decimal? VatRate { get; set; }

        /// <summary>
        /// Hóa đơn có thuế là KHAC  
        /// </summary>
        public bool IsVatOther { get; set; }

        /// <summary>
        /// Tổng tiền thuế
        /// </summary>
        public decimal TotalVATAmount { get; set; }

        /// <summary>
        /// Tổng tiền chiết khấu
        /// </summary>
        public decimal TotalDiscountAmount { get; set; }

        /// <summary>
        /// Tổng tiền thanh toán, đã bao gồm VAT và chiết khấu
        /// </summary>
        public decimal TotalAmount { get; set; }

        /// <summary>
        /// PPDANG: 06.07.2022
        /// Do có lỗi từ NCC Fast JIRA INVBOT-4935, tiền chiết khấu bị loạn nên cần giữ nguyên trường này để đi tra cứu trên CQT
        /// Tổng tiền thanh toán gốc trong XML
        /// </summary>
        public decimal TotalAmountOrigin { get; set; }

        /// <summary>
        /// Đọc tiền từ số thành chữ
        /// </summary>
        public string TotalAmountText { get; set; }

        /// <summary>
        /// Tổng tiền khác
        /// </summary>
        public List<OtherInfo> TotalOthers { get; set; }

        /// <summary>
        /// Thông tin hàng hóa của hóa đơn
        /// </summary>
        public List<InvoiceItemInfo> Items { get; set; }

        /// <summary>
        /// Trạng thái kiểm tra hóa đơn
        /// </summary>        
        public InvoiceInfoStatusFlags Status { get; set; } = InvoiceInfoStatusFlags.WaitChecking;

        public bool IsDeleted { get; set; } = false;

        /// <summary>
        /// Ghi chú
        /// </summary>
        public string Noted { get; set; } = "";


        /// <summary>
        /// Kiểm tra xem có phải hóa đơn 123 không
        /// </summary>
        public bool IsInvoice123
        {
            get
            {
                return InvoiceUtility.IsInvoice123(TemplateNo, Series);
            }
        }

        /// <summary>
        /// Loại Hóa đơn (Có mã /Không mã /...)
        /// </summary>
        public InvoiceCodeStatus InvoiceCodeStatus
        {
            get
            {
                if (!IsInvoice123) return InvoiceCodeStatus.None;
                //Hóa đơn có mã
                if (Series.StartsWith("C")) return InvoiceCodeStatus.WithCode;
                //Hóa đơn Không mã
                if (Series.StartsWith("K")) return InvoiceCodeStatus.WithoutCode;
                return InvoiceCodeStatus.None;
            }
        }

        /// <summary>
        /// Trường hỗ trợ để phục vụ theo Nghị Định 123 của chính phủ
        /// </summary>
        public List<OtherInfo> Others { get; set; }

        /// <summary>
        ///  DSLPhi trong hóa đơn Nghị định 123
        /// </summary>
        public List<FeesInfo> Fees { get; set; }

        /// <summary>
        /// Tổng tiền phí trong Hóa đơn Nghị định 123
        /// </summary>
        public decimal TotalFeesAmount
        {
            get
            {
                var registationFee = 0;
                if (Fees != null && Fees.Count() > 0)
                {
                    var fees = Fees.Where(x => x.TPhi != null).ToList();
                    if (fees != null && fees.Count() > 0) return (fees.Sum(x => x.TPhi) ?? 0) + registationFee;
                }
                return registationFee;
            }
        }

        /// <summary>
        /// Hóa đơn có hỗ trợ theo NQ 406 hay không?
        /// </summary>
        public bool IsTaxReduction { get; set; }

        /// <summary>
        /// Số tiền được giảm trong hóa đơn bán hàng theo NQ 406
        /// </summary>
        public decimal TotalTaxReductionAmount { get; set; }

        /// <summary>
        /// Hóa đơn có hỗ trợ theo NQ 43 không?
        /// </summary>
        public bool IsTaxReduction43 { get; set; }

        /// <summary>
        /// Số tiền được giảm trong hóa đơn bán hàng theo NQ 43
        /// </summary>
        public decimal TotalTaxReductionAmount43 { get; set; }

        /// <summary>
        /// Hóa đơn dùng tiền VND hay nguyên tệ
        /// </summary>
        public bool IsVND => InvoiceUtility.IsVND(CcyCode);

        /// <summary>
        /// Là biên lai khi mẫu số hóa đơn có BLP
        /// </summary>
        public bool IsReceipt => InvoiceUtility.IsReceipt(TemplateNo);

        /// <summary>
        /// Các mẫu hóa đơn theo dạng custom để hiển thị đúng mẫu thông tin
        /// </summary>
        public InvoiceCustomTemplate InvCustomTemplate { get; set; }

        /// <summary>
        /// Có hiển thị text giảm trừ theo NQ406 hay không
        /// Chỉ hiển thị dòng này với hóa đơn bán hàng
        /// </summary>
        public bool IsDisplayTaxReductionNQ406 => IsTaxReduction && IsInvoiceSale && TotalTaxReductionAmount > 0;

        /// <summary>
        /// Có hiển thị text giảm trừ theo NQ43 hay không
        /// Chỉ hiển thị dòng này với hóa đơn bán hàng
        /// </summary>
        public bool IsDisplayTaxReductionNQ43 => IsTaxReduction43 && IsInvoiceSale && TotalTaxReductionAmount43 > 0;

        /// <summary>
        /// Tên hóa đơn: Hóa đơn giá trị gia tăng, Hóa đơn bán hàng...
        /// </summary>
        public string InvoiceName { get; set; }

        /// <summary>
        /// Mã cơ quan thuế cấp
        /// </summary>
        public string MCCQT { get; set; }

        /// <summary>
        /// Dùng để hiển thị ở client
        /// </summary>
        public string MCCQTText
        {
            get
            {
                return !string.IsNullOrEmpty(MCCQT) ? $"Mã CQT cấp: {MCCQT}" : null;
            }
        }

        /// <summary>
        /// Là hóa đơn chiết khấu
        /// </summary>
        public bool IsDiscountInvoice
        {
            get
            {
                return Items != null && Items.Exists(x => x.Kind == KindND123Enum.Discount) && !Items.Exists(x => x.Kind == KindND123Enum.Info);
            }
        }

        /// <summary>
        /// Tổng tiền hàng hiển thị ở template bao gồm cả tiền chiết khấu
        /// </summary>
        public decimal TotalAmountWithoutVatDisplay
        {
            get
            {
                //Hóa đơn NĐ123
                if (IsInvoice123)
                {
                    if (IsDiscountInvoice) return TotalAmountWithoutVat;
                    var amount = TotalAmountWithoutVat + TotalDiscountAmount;
                    return amount;
                }
                else//Hóa đơn NĐ51
                {
                    decimal amount = 0;
                    if (Items != null && Items.Count() > 0) { amount = Items.Sum(n => Math.Abs(n.AmountWithoutVatDisplay)); }
                    //Nếu không có tiền hàng trong chi tiết thì lấy tiền hàng của Master
                    if (amount <= 0) { amount = TotalAmountWithoutVat + TotalDiscountAmount; }
                    if ((amount > TotalAmountWithoutVat - 1 && amount < TotalAmountWithoutVat + 1) || SpecialCase) { return TotalAmountWithoutVat; }
                    return amount;
                }
            }
        }

        //Trường hợp đặc biệt
        public bool SpecialCase
        {
            get
            {
                // Xử lý bug 144633
                if (SellerTaxCode.Equals("0300741217") && TemplateNo.Equals("01GTKT0/002")
                    && InvoiceNo.Equals("5575") && Series.Equals("SC/20E"))
                {
                    return true;
                }
                else if (SellerTaxCode.Equals("0100100417-024") && TemplateNo.Equals("01GTKT0/002"))
                {
                    return true;
                }
                else if (SellerTaxCode.Contains("0200128737")) // BUG 160037
                {
                    return true;
                }
                return false;
            }
        }

        /// <summary>
        ///Tổng tiền khuyến mại có tính chất = 2(Tiền khuyến mại)
        /// </summary>
        public decimal TotalPromotionItemND123
        {
            get
            {
                if (!IsInvoice123) return 0;
                if (Items == null || Items.Count() <= 0) return 0;
                var total = Items.Where(x => x.Kind == KindND123Enum.Promotion).Sum(x => Math.Abs(x.AmountWithoutVatDisplay));
                return total;
            }
        }

        /// <summary>
        ///Tổng tiền hàng có tính chất bằng 3(Tiền chiết khấu thương mại)
        /// </summary>
        public decimal TotalDiscountItemND123
        {
            get
            {
                if (!IsInvoice123) return 0;
                if (Items == null || Items.Count() <= 0) return 0;
                var total = Items.Where(x => x.Kind == KindND123Enum.Discount).Sum(x => Math.Abs(x.AmountWithoutVatDisplay));
                var totalDiscountInItem = Items.Where(x => x.Kind == KindND123Enum.Info).Sum(x => Math.Abs(x.DiscountAmount));
                return total + totalDiscountInItem;
            }
        }

        /// <summary>
        ///Tổng tiền ghi chú có tính chất = 4 (Ghi chú)
        /// </summary>
        public decimal TotalNotedItemND123
        {
            get
            {
                if (!IsInvoice123) return 0;
                if (Items == null || Items.Count() <= 0) return 0;
                var total = Items.Where(x => x.Kind == KindND123Enum.Noted).Sum(x => Math.Abs(x.AmountWithoutVatDisplay));
                return total;
            }
        }

        /// <summary>
        /// Chi nhánh sử dụng thông báo phát hành của Công ty
        /// </summary>
        public bool IsUserPublishNoticeCompany { get; set; }

        /// <summary>
        /// Tên của hóa đơn hiển thị ở Client
        /// </summary>
        public string TitleInvoiceText
        {
            get
            {
                if ((IsInvoice123 && !string.IsNullOrEmpty(InvoiceName)) || !string.IsNullOrEmpty(InvoiceName))
                {
                    return InvoiceName.ToUpper();
                }
                else if (IsReceipt)
                {
                    return "BIÊN LAI THU TIỀN PHÍ, LỆ PHÍ";
                }
                else
                {
                    return GetTextTitleTemplateInvoice();
                }
            }
        }

        /// <summary>
        /// Thông tin dữ liệu theo ND 123
        /// </summary>
        public ND123Info InfoND123 { get; set; } = new ND123Info();

        /// <summary>
        /// Trạng thái hóa đơn
        /// </summary>
        public int? StatusInvoice { get; set; }

        /// <summary>
        /// Tổng tiền quy đổi
        /// </summary>
        public decimal TotalAmountExchange
        {
            get
            {
                // Nếu là tiền VND thì lấy luôn TotalAmount
                if (IsVND) return TotalAmount;

                // Nếu là nguyên tệ thì * tỉ giá
                if (ExchangeRate != null)
                {
                    return TotalAmount * ExchangeRate.Value;
                }
                else
                {
                    return TotalAmount;
                }
            }
        }

        public string ItemNamesText
        {
            get
            {
                if (Items != null && Items.Count() > 0 && IsReceipt)
                {
                    var itemNames = Items.Where(n => !string.IsNullOrEmpty(n.ItemName)).Select(n => n.ItemName);
                    if (itemNames != null && itemNames.Count() > 0) { return string.Join("; ", itemNames); }
                }
                return "";
            }
        }

        /// <summary>
        /// Cờ kiểm tra xem có phải hóa đơn điện tử máy tính tiền hay không?
        /// </summary>
        public bool IsRegisterCash => Series.IndexOf("M") == 3;

        #endregion
        public string ToInfoString()
        {
            return $"{SellerTaxCode}-{TemplateNo}-{Series}-{InvoiceNo}";
        }

        public string GetTextTitleTemplateInvoice()
        {
            var title = "HÓA ĐƠN GIÁ TRỊ GIA TĂNG";
            switch (InvCustomTemplate)
            {
                case InvoiceCustomTemplate.InvoiceSales:
                    title = "HÓA ĐƠN BÁN HÀNG";
                    break;
                case InvoiceCustomTemplate.AgentWarehouseExport:
                    title = "PHIẾU XUẤT KHO HÀNG GỬI ĐẠI LÝ";
                    break;
                case InvoiceCustomTemplate.InternalWarehouseExport:
                    title = "PHIẾU XUẤT KHO KIÊM VẬN CHUYỂN NỘI BỘ";
                    break;
            }
            return title;
        }

        public string InvoiceDateText
        {
            get
            {
                if (InvoiceDate != null)
                {
                    var invoiceDate = InvoiceDate;
                    return $"Ngày {invoiceDate.Day:D2} tháng {invoiceDate.Month:D2} năm {invoiceDate.Year}";
                }
                return string.Empty;
            }
        }
    }

    public static class InvoiceUtility
    {
        public static bool IsMatch(string text, string pattern)
        {
            return Regex.IsMatch(text, pattern);
        }
        public static bool IsInvoice123(string templateNo, string series)
        {
            return !string.IsNullOrEmpty(templateNo) && !IsMatch(templateNo, "((\\d{2})([A-Z]{4})(\\d)((/)|(-))(\\d{3}))")
                         && !string.IsNullOrEmpty(series) && IsMatch(series, "(([A-Z]{1})(\\d{2})([A-Z0-9]{3}))")
                         && int.TryParse(templateNo, out _);
        }
        public static bool IsReceipt(string templateNo)
        {
            return !string.IsNullOrEmpty(templateNo) && IsMatch(templateNo, "((\\d{2})([A-Z]{3})(\\d)((-))(\\d{3}))");
        }
        public static List<string> GetCurrencyVnds() => new List<string> { null, "", "VND", "VNĐ", "vnd", "vnđ", "Đ", "đ" };
        public static bool IsVND(string ccyCode)
        {
            return string.IsNullOrEmpty(ccyCode) || GetCurrencyVnds().Exists(n => !string.IsNullOrEmpty(n) && n.Equals(ccyCode));
        }
        public static string GetHDon(string templateNo, string series)
        {
            try
            {
                //Chỉ xử lý đối với hóa đơn 123
                if (!IsInvoice123(templateNo, series)) return "";
                int.TryParse(templateNo, out int numberTemplateNo);
                if (numberTemplateNo <= 0) return "";

                //Nếu là hóa đơn điều chuyển nội bộ, xuất bán đại lý...
                if (numberTemplateNo == 6)
                {
                    //Nếu là điều chuyển nội bộ - C22NAB
                    if (IsMatch(series, "(([A-Z]{1})(\\d{2})N([A-Z0-9]{2}))"))
                    {
                        return "06_01";
                    }
                    //Nếu là gửi bán đại lý - C22BAB
                    else if (IsMatch(series, "(([A-Z]{1})(\\d{2})B([A-Z0-9]{2}))"))
                    {
                        return "06_02";
                    }
                }

                //Giá trị mặc định
                return numberTemplateNo.ToString("D2") ?? "";
            }
            catch (Exception ex)
            {
                LogUtil.LogError(ex);
                return "";
            }

        }
        public static bool IsTicketNoCode(string templateNo, string series)
        {
            return templateNo.Contains("5") && series.IndexOf("K") == 0;
        }
    }

    public class ProcessTemplateND123Utility
    {
        public static InvoiceCustomTemplate? GetTemplate(string templateNo, string series)
        {
            if (templateNo == ((int)KyHieuMauSoEnum.ChungTuNhuHDon).ToString())
            {
                //Nội bộ
                if (InvoiceUtility.GetHDon(templateNo, series).Equals("06_01"))
                {
                    return InvoiceCustomTemplate.InternalWarehouseExport;
                }
                //Điều chuyển đại lý
                else if (InvoiceUtility.GetHDon(templateNo, series).Equals("06_02"))
                {
                    return InvoiceCustomTemplate.AgentWarehouseExport;
                }
                else
                {
                    return null;
                }
            }
            else if (templateNo == ((int)KyHieuMauSoEnum.Khac).ToString())
            {
                return InvoiceCustomTemplate.Invoice123;
            }
            else if (templateNo == ((int)KyHieuMauSoEnum.DTruQuocGia).ToString())
            {
                return null;
            }
            else if (templateNo == ((int)KyHieuMauSoEnum.TSanCong).ToString())
            {
                return null;
            }
            else if (templateNo == ((int)KyHieuMauSoEnum.BanHang).ToString())
            {
                return InvoiceCustomTemplate.InvoiceSales;
            }
            else if (templateNo == ((int)KyHieuMauSoEnum.GTGT).ToString())
            {
                return InvoiceCustomTemplate.Invoice123;
            }
            else
            {
                return null;
            }
        }
    }

    /// <summary>
    /// Tham số khi thực hiện Đối chiếu tờ khai
    /// </summary>
    public class RequestSyncTaxAuthorityToCompare : BaseReceiveMessageFromAccounting
    {
        /// <summary>
        /// ID tờ khai thực hiện đối chiếu
        /// </summary>
        public Guid? DeclarationRefid { get; set; }

        /// <summary>
        /// Reftype của tờ khai thực hiện đối chiếu
        /// </summary>
        public int? DeclarationReftype { get; set; }

        /// <summary>
        /// Tên tờ khai thực hiện đối chiếu
        /// </summary>
        public string DeclarationName { get; set; }

        /// <summary>
        /// Tờ bổ sung lần thứ
        /// </summary>
        public int? AdditionTime { get; set; }

        /// <summary>
        /// Ngày bắt đầu
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Ngày kết thúc
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Loại đồng bộ hóa đơn (0. HĐ đầu vào, 1. HĐ đầu ra, 2. Cả 2)
        /// </summary>
        public int SyncFromTypeInvoice { get; set; }

        /// <summary>
        /// Có lấy hóa đơn ủy nhiệm không
        /// </summary>
        public bool IsPaymentOrder { get; set; } = false;
        /// <summary>
        /// API call back lại kế toán
        /// </summary>
        public string APISyncCallback { get; set; }

        /// <summary>
        /// Loại đối chiếu: 1.Tờ khai, 2.Đầu vào, 3.Đầu ra
        /// </summary>
        public int CompareType { get; set; }
    }

    /// <summary>
    /// Enum loại đối chiếu
    /// </summary>
    public enum EnumCompareType
    {
        /// <summary>
        /// Đối chiếu tờ khai
        /// </summary>
        Declaration = 1,

        /// <summary>
        /// Đối chiếu hóa đơn đầu vào trên danh sách hđ
        /// </summary>
        InputInvoice = 2,

        /// <summary>
        /// Đối chiếu hóa đơn trên danh sách hđ
        /// </summary>
        OutputInvoice = 3
    }

    /// <summary>
    /// Loại đồng bộ hóa đơn: đầu ra, đầu vào, cả 2
    /// </summary>
    public enum EnumSyncFromTypeInvoice
    {
        /// <summary>
        /// HĐ đầu ra
        /// </summary>
        OutputInvoice = 0,

        /// <summary>
        /// HĐ đầu vào
        /// </summary>
        InputInvoice = 1,

        /// <summary>
        /// Cả 2
        /// </summary>
        All = 2
    }

    /// <summary>
    /// Tham số đẩy sang Kế toán (đối chiếu)
    /// </summary>
    public class TaxAuthoritySyncFromToolToCompare
    {
        /// <summary>
        /// ID tờ khai thực hiện đối chiếu
        /// </summary>
        public Guid? DeclarationRefid { get; set; }
        /// <summary>
        /// Reftype của tờ khai thực hiện đối chiếu
        /// </summary>
        public int? DeclarationReftype { get; set; }
        /// <summary>
        /// Tên tờ khai thực hiện đối chiếu
        /// </summary>
        public string DeclarationName { get; set; }
        /// <summary>
        /// Tờ bổ sung lần thứ
        /// </summary>
        public int? AdditionTime { get; set; }
        /// <summary>
        /// ngày bắt đầu
        /// </summary>
        public DateTime StartDate { get; set; }
        /// <summary>
        /// Ngày kết thúc
        /// </summary>
        public DateTime EndDate { get; set; }
        /// <summary>
        /// Mã số thuế công ty
        /// </summary>
        public string TaxCode { get; set; }
        /// <summary>
        /// Mã số thuế công ty
        /// </summary>
        public string SubscriberId { get; set; }
        /// <summary>
        /// Mã số thuế công ty
        /// </summary>
        public string OrganizationId { get; set; }
        /// <summary>
        /// Tổng số hóa đơn lấy về được
        /// </summary>
        public int TotalCrawl { get; set; }
        /// <summary>
        /// Loại đối chiếu
        /// </summary>
        public int CompareType { get; set; }
        /// <summary>
        /// Danh sách hóa đơn (dạng master từ HDDT)
        /// </summary>
        public List<InvoiceBotResponse> ListInvoiceMaster { get; set; }
    }
}