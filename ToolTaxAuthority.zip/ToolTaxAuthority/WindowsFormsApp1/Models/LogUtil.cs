﻿using Newtonsoft.Json;
using System;
using System.IO;

namespace WindowsFormsApp1.Models
{
    public class LogUtil
    {
        private static readonly string LogFilePath = $"{FileUtil.LOG_PATH}\\{DateTime.Now:dd-MM-yyyy}.txt";

        public static void LogInfo(string message, bool hasDateTime = true)
        {
            SaveToFile($"INFO: {message}", hasDateTime);
        }
        public static void LogInfo(object obj, bool hasDateTime = true)
        {
            if (obj == null)
            {
                return;
            }
            SaveToFile($"INFO: {JsonConvert.SerializeObject(obj)}", hasDateTime);
        }
        public static void LogError(string message, bool hasDateTime = true)
        {
            SaveToFile($"ERROR: {message}", hasDateTime);
        }
        public static void LogError(object obj, bool hasDateTime = true)
        {
            if (obj == null)
            {
                return;
            }
            SaveToFile($"ERROR: {JsonConvert.SerializeObject(obj)}", hasDateTime);
        }
        public static void LogWarning(string message, bool hasDateTime = true)
        {
            SaveToFile($"WARNING: {message}", hasDateTime);
        }
        public static void LogWarning(object obj, bool hasDateTime = true)
        {
            if (obj == null)
            {
                return;
            }
            SaveToFile($"WARNING: {JsonConvert.SerializeObject(obj)}", hasDateTime);
        }
        private static readonly object lockObject = new object();

        static void SaveToFile(string message, bool hasDateTime = true)
        {
            string directoryPath = Path.GetDirectoryName(LogFilePath);

            // Check if the directory exists, and create it if it doesn't.
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            string logMessage = hasDateTime ? $"{DateTime.Now:dd/MM/yyyy HH:mm:ss:fff} - {message}" : message;

            lock (lockObject)
            {
                using (StreamWriter writer = File.AppendText(LogFilePath))
                {
                    writer.WriteLine(logMessage);
                }
            }
        }
    }
}
