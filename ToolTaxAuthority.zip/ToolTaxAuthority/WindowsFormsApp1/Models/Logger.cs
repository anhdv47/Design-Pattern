﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace WindowsFormsApp1.Models
{
    public class Logger
    {
        private static readonly string LogFilePath = $"{AppDomain.CurrentDomain.BaseDirectory}Logs\\{DateTime.Now:dd-MM-yyyy}.txt";

        public static void LogInfo(string message, bool hasDateTime = true)
        {
            SaveToFile($"INFO: {message}", hasDateTime);
        }
        public static void LogInfo(object obj, bool hasDateTime = true)
        {
            if (obj == null)
            {
                return;
            }
            SaveToFile($"INFO: {JsonConvert.SerializeObject(obj)}", hasDateTime);
        }
        public static void LogError(string message, bool hasDateTime = true)
        {
            SaveToFile($"ERROR: {message}", hasDateTime);
        }
        public static void LogError(object obj, bool hasDateTime = true)
        {
            if (obj == null)
            {
                return;
            }
            SaveToFile($"ERROR: {JsonConvert.SerializeObject(obj)}", hasDateTime);
        }
        public static void LogWarning(string message, bool hasDateTime = true)
        {
            SaveToFile($"WARNING: {message}", hasDateTime);
        }
        public static void LogWarning(object obj, bool hasDateTime = true)
        {
            if (obj == null)
            {
                return;
            }
            SaveToFile($"WARNING: {JsonConvert.SerializeObject(obj)}", hasDateTime);
        }
        static void SaveToFile(string message, bool hasDateTime = true)
        {
            string filePath = LogFilePath;
            if (!File.Exists(filePath))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(filePath));
                File.Create(filePath).Close();
            }
            using (StreamWriter writer = File.AppendText(filePath))
            {
                if (hasDateTime)
                {
                    writer.WriteLine($"{DateTime.Now:dd/MM/yyyy HH:mm:ss:fff} - {message}");
                }
                else
                {
                    writer.WriteLine(message);
                }
            }
        }
    }
}
