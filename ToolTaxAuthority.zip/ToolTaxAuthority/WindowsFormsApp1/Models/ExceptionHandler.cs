﻿using System;

namespace WindowsFormsApp1.Models
{
    public interface IBreakRetryException
    {
    }

    public class DownloadXMLException : Exception, IBreakRetryException
    {
        public DownloadXMLException(string message) : base(message)
        {
        }
    }
}
