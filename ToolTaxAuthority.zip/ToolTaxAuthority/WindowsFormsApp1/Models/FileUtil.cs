﻿using System;

namespace WindowsFormsApp1.Models
{
    public class FileUtil
    {
        // thư mục chứa File của ứng dụng
        public static string BASE_PATH = AppDomain.CurrentDomain.BaseDirectory;
        // thư mục chứa File Log
        public static string LOG_PATH = BASE_PATH + "Logs";
        // thư mục chứa File Token
        public static string TOKEN_PATH = BASE_PATH + "Tokens";
        // thư mục chứa File Data
        public static string DATA_PATH = BASE_PATH + "Data";
    }
}
