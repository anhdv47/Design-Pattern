﻿using Fleck;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Windows.Forms;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{
    static class Program
    {
        public static ToolStripProgressBar ProgressBarGlobal { get; set; }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            var server = new WebSocketServer("ws://0.0.0.0:12308")
            {
                RestartAfterListenError = true
            };

            // Initial and start WebSocket Service.
            server.Start(socket =>
            {
                socket.OnOpen = () => { };
                socket.OnClose = () => { };
                socket.OnMessage = async (message) =>
                {
                    if (!string.IsNullOrEmpty(message))
                    {
                        var actionInfor = JsonConvert.DeserializeObject<ActionInfor>(message);

                        EInvoiceCrawler eInvoiceCrawler = null;
                        // dựa trên loại hành động để quyết định xử lý nghiệp vụ tương ứng
                        switch (actionInfor.ActionType)
                        {
                            case 7:
                            case 8:
                                //// Lấy trạng thái hóa đơn đầu vào/ra
                                //eInvoiceCrawler = new EInvoiceCrawler();
                                //await eInvoiceCrawler.GetInvoicesStatuseNoAuthorizationAsync(actionInfor.Data);
                                break;
                            case 9:
                                //// Đồng bộ hóa đơn đầu vào
                                //var syncRequest = JsonConvert.DeserializeObject<RequestSyncTaxAuthority>(actionInfor.Data);
                                //eInvoiceCrawler = new EInvoiceCrawler(syncRequest.TaxCode, syncRequest.Username, syncRequest.Password);
                                //syncRequest.IsSyncFromInputInvoice = true;
                                //await eInvoiceCrawler.SyncInvoiceInRange(syncRequest);
                                break;
                            case 10:
                                //// Đồng bộ hóa đơn đầu ra
                                //var syncOutRequest = JsonConvert.DeserializeObject<RequestSyncTaxAuthority>(actionInfor.Data);
                                //eInvoiceCrawler = new EInvoiceCrawler(syncOutRequest.TaxCode, syncOutRequest.Username, syncOutRequest.Password);
                                //syncOutRequest.IsSyncFromInputInvoice = false;
                                //await eInvoiceCrawler.SyncInvoiceInRange(syncOutRequest);
                                break;
                            case 11:
                                // Xem chi tiết hóa đơn
                                var viewInvoiceRequest = JsonConvert.DeserializeObject<ViewInvoiceFromTaxAuthority>(actionInfor.Data);
                                eInvoiceCrawler = new EInvoiceCrawler(viewInvoiceRequest.TaxCode, viewInvoiceRequest.Username, viewInvoiceRequest.Password);
                                await eInvoiceCrawler.ViewInvoiceFromTaxAuthority(viewInvoiceRequest, socket);
                                break;
                            case 12:
                                // Tải xml
                                //var downloadInvoiceRequest = JsonConvert.DeserializeObject<ViewInvoiceFromTaxAuthority>(actionInfor.Data);
                                //eInvoiceCrawler = new EInvoiceCrawler(downloadInvoiceRequest.TaxCode, downloadInvoiceRequest.Username, downloadInvoiceRequest.Password, false);
                                //await eInvoiceCrawler.DownloadInvoiceFromTaxAuthority(downloadInvoiceRequest, socket);
                                break;
                            case 99:
                                await socket.Send("");
                                break;
                            default:
                                MessageBox.Show("Không xác định được hành động!");
                                break;
                        }

                    }
                };
                socket.OnError = ex =>
                {
                    LogUtil.LogInfo($"WebSocketServer Error {JsonConvert.SerializeObject(ex)}");
                };
            });
            Application.Run(new Form1());
        }
    }
}
