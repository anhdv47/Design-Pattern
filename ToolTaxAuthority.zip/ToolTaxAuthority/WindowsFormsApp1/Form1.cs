﻿using Fleck;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Windows.Forms;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{
    public partial class Form1 : BaseForm
    {
        private HttpClient _client;
        private bool isClosingFromForm = false;
        readonly string mutexName = Path.GetFileName(Application.ExecutablePath);

        public Form1()
        {
            _ = new Mutex(true, mutexName, out bool createdNew);
            if (!createdNew)
            {

            }
            InitializeComponent();
            Program.ProgressBarGlobal = progressBar;
            _client = new HttpClient();
            notifyIcon1.ShowBalloonTip(1000, "Công cụ đồng bộ", "Đã chạy", ToolTipIcon.None);
        }

        private DataGridViewCell GetCellWhereTextExistsInGridView(string searchText, DataGridView dataGridView, List<string> columnNames)
        {
            DataGridViewCell cellWhereTextIsMet = null;

            foreach (string columnName in columnNames)
            {
                int columnIndex = -1;
                foreach (DataGridViewColumn column in dataGridView.Columns)
                {
                    if (column.Name == columnName)
                    {
                        columnIndex = column.Index;
                        break;
                    }
                }

                if (columnIndex != -1)
                {
                    foreach (DataGridViewRow row in dataGridView.Rows)
                    {
                        if (row.Cells[columnIndex].Value != null && searchText == row.Cells[columnIndex].Value.ToString())
                        {
                            cellWhereTextIsMet = row.Cells[columnIndex];
                            break;
                        }
                    }
                }

                if (cellWhereTextIsMet != null)
                {
                    break; // Dừng nếu đã tìm thấy kết quả trong một trong các cột
                }
            }

            return cellWhereTextIsMet;
        }

        private void sohoadon_TextChanged(object sender, EventArgs e)
        {
            string searchText = sohoadon.Text;
            var columnName = new List<string> { "InvoiceNo" };



            DataGridViewCell cell = GetCellWhereTextExistsInGridView(searchText, lstInvoice, columnName);

            if (cell != null)
            {
                // Value exists in the grid
                cell.Style = new DataGridViewCellStyle { ForeColor = Color.Red };

                // Tìm và cuộn đến dòng chứa ô
                int rowIndex = cell.RowIndex;

                if (rowIndex >= 0 && rowIndex < lstInvoice.Rows.Count)
                {
                    // Cuộn đến dòng chứa ô nếu nó không nằm trong tầm nhìn của DataGridView
                    lstInvoice.FirstDisplayedScrollingRowIndex = rowIndex;
                }
            }
            else
            {
                // Value does not exist in the grid
                // Xóa style nếu không tìm thấy
                //sohoadon.Clear(); // Xóa văn bản trong textbox
                ResetCellStyle(lstInvoice, columnName);
            }
        }

        private void ResetCellStyle(DataGridView dataGridView, List<string> columnNames)
        {
            foreach (string columnName in columnNames)
            {
                foreach (DataGridViewRow row in dataGridView.Rows)
                {
                    if (row.Cells[columnName] != null)
                    {
                        row.Cells[columnName].Style = new DataGridViewCellStyle(); // Đặt lại style cho ô trong cột
                    }
                }
            }
        }

        /// <summary>
        /// Giá trị mặc định
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            var acc = new List<Account>();
            acc.Add(new Account
            {
                Username = "0107001729",
                Password = "Tct@2023"
            });

            cboUsername.DataSource = acc;
            cboUsername.DisplayMember = "Username";
            cboUsername.ValueMember = "Password";
            cboUsername.SelectedIndex = 0;
            textBoxPassword.Text = cboUsername.SelectedValue.ToString();
            cboUsername.SelectedIndexChanged += CboUsernameCombobox_SelectedIndexChanged;

            List<EInvoiceTab> tabs = new List<EInvoiceTab>();
            tabs.Add(new EInvoiceTab()
            {
                TabIndex = 0,
                TabName = "Hóa đơn điện tử bán ra"
            });
            tabs.Add(new EInvoiceTab()
            {
                TabIndex = 1,
                TabName = "Hóa đơn điện tử mua vào"
            });
            invoiceTypeCombobox.DataSource = tabs;
            invoiceTypeCombobox.DisplayMember = "TabName";
            invoiceTypeCombobox.ValueMember = "TabIndex";
            invoiceTypeCombobox.SelectedIndex = 0;
            // mặc định nếu không thay đổi combox tra cứu hóa đơn thì mặc định là hóa đơn điện tử mua vào
            InvoiceTypeCombobox_SelectedIndexChanged(null, null);
            // check thay đổi combox tra cứu hóa đơn
            invoiceTypeCombobox.SelectedIndexChanged += InvoiceTypeCombobox_SelectedIndexChanged;
            toDate.Value = DateTime.Now;
            fromDate.Value = toDate.Value.AddMonths(-1);

            var decaptchaUrl = new List<DecaptchaObj>();
            decaptchaUrl.Add(new DecaptchaObj
            {
                Url = "https://aiservice.misa.vn/v2/captcha-decode/",
                XApiKey = "RDtZbUSo5yPYsOBmU4utkLDGH9p5qGFE",
                Project = "misa-asp",
            });
            decaptchaUrl.Add(new DecaptchaObj
            {
                Url = "https://aiservice.misa.vn/v1/captcha-decode/",
                XApiKey = "P4wrZDzouW50s8xfpD5E26Fe3MPbX3G0",
                Project = "invoice-scanner",
            });
            cboApiKey.DataSource = decaptchaUrl;
            cboApiKey.DisplayMember = "Url";
            cboApiKey.ValueMember = "Project";
            cboApiKey.SelectedIndex = 0;
            CboApiSetValue();
            cboApiKey.SelectedIndexChanged += CboApiKeyCombobox_SelectedIndexChanged;
        }

        private void CboApiSetValue()
        {
            var cboApiSelected = (DecaptchaObj)cboApiKey.SelectedItem;
            switch (cboApiSelected.Project)
            {
                case "invoice-scanner":
                    txtBoxXApiKey.Text = "P4wrZDzouW50s8xfpD5E26Fe3MPbX3G0";
                    txtProjectName.Text = "invoice-scanner";
                    break;
                case "misa-asp":
                    txtBoxXApiKey.Text = "RDtZbUSo5yPYsOBmU4utkLDGH9p5qGFE";
                    txtProjectName.Text = "misa-asp";
                    break;
            }

            MisaDecaptcha.PROJECT = txtProjectName.Text;
            MisaDecaptcha.XAPIKEY = txtBoxXApiKey.Text;
            MisaDecaptcha.URL = cboApiSelected.Url;
        }

        private void CboApiKeyCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            CboApiSetValue();
        }

        private void CboUsernameCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBoxPassword.Text = cboUsername.SelectedValue.ToString();
        }

        private void InvoiceTypeCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedTab = invoiceTypeCombobox.SelectedItem as EInvoiceTab;
            // hóa đơn điện tử mua vào
            List<InvoiceStatus> invoiceStatuses = new List<InvoiceStatus>();
            List<InvoiceCheckResult> invoiceCheckResults = new List<InvoiceCheckResult>();
            // hóa đơn điện tử mua vào
            // trạng thái hóa đơn
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 0,
                StatusName = "Tất cả"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 1,
                StatusName = "Hóa đơn mới"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 2,
                StatusName = "Hóa đơn thay thế"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 3,
                StatusName = "Hóa đơn điều chỉnh"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 4,
                StatusName = "Hóa đơn đã bị thay thế"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 5,
                StatusName = "Hóa đơn đã bị điều chỉnh"
            });
            invoiceStatuses.Add(new InvoiceStatus()
            {
                Status = 6,
                StatusName = "Hóa đơn đã bị hủy"
            });

            tthaiCombobox.DataSource = invoiceStatuses;
            tthaiCombobox.DisplayMember = "StatusName";
            tthaiCombobox.ValueMember = "Status";
            tthaiCombobox.SelectedIndex = 0;
            invoiceCheckResults.Add(new InvoiceCheckResult()
            {
                Result = -1,
                ResultName = "Tất cả"
            });

            if (selectedTab.TabIndex == 0)
            {
                // hóa đơn điện tử bán ra
                // 0: "Tổng cục Thuế đã nhận",
                // 1: "Đang tiến hành kiểm tra điều kiện cấp mã",
                // 2: "CQT từ chối hóa đơn theo từng lần phát sinh",
                // 3: "Hóa đơn đủ điều kiện cấp mã",
                // 4: "Hóa đơn không đủ điều kiện cấp mã",
                // 5: "Đã cấp mã hóa đơn",
                // 6: "Tổng cục thuế đã nhận không mã",
                // 7: "Đã kiểm tra định kỳ HĐĐT không có mã",
                // 8: "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 0,
                    ResultName = "Tổng cục Thuế đã nhận"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 1,
                    ResultName = "Đang tiến hành kiểm tra điều kiện cấp mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 2,
                    ResultName = "CQT từ chối hóa đơn theo từng lần phát sinh"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 3,
                    ResultName = "Hóa đơn đủ điều kiện cấp mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 4,
                    ResultName = "Hóa đơn không đủ điều kiện cấp mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 5,
                    ResultName = "Đã cấp mã hóa đơn"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 6,
                    ResultName = "Tổng cục thuế đã nhận không mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 7,
                    ResultName = "Đã kiểm tra định kỳ HĐĐT không có mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 8,
                    ResultName = "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                });
            }
            else
            {
                // 5: "Đã cấp mã hóa đơn",
                // 6: "Tổng cục thuế đã nhận không mã",
                // 8: "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 5,
                    ResultName = "Đã cấp mã hóa đơn"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 6,
                    ResultName = "Tổng cục thuế đã nhận không mã"
                });
                invoiceCheckResults.Add(new InvoiceCheckResult()
                {
                    Result = 8,
                    ResultName = "Tổng cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền"
                });

            }

            ttxlyCombobox.DataSource = invoiceCheckResults;
            ttxlyCombobox.DisplayMember = "ResultName";
            ttxlyCombobox.ValueMember = "Result";
            ttxlyCombobox.SelectedIndex = 0;
        }

        private void fromDate_ValueChanged(object sender, EventArgs e)
        {
            toDate.Value = fromDate.Value.AddMonths(1);
        }

        private async void BtnGetInvoicesInRangeClick(object sender, EventArgs e)
        {
            button1.Enabled = false;
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            try
            {
                InvoiceInfoRequest request = new InvoiceInfoRequest();
                request.StartDate = fromDate.Value;
                request.EndDate = toDate.Value;
                request.EinvoiceTab = (int)invoiceTypeCombobox.SelectedValue;
                request.InvoiceStatus = (int)tthaiCombobox.SelectedValue;
                request.InvoiceCheckResult = (int)ttxlyCombobox.SelectedValue;
                request.Unhiem = uynhiemCheckbox.Checked;

                var crawler = new EInvoiceCrawler(cboUsername.Text, cboUsername.Text, textBoxPassword.Text, isFromAsp: false);
                RequestSyncTaxAuthority requestSyncTax = new RequestSyncTaxAuthority
                {
                    StartDate = fromDate.Value,
                    EndDate = toDate.Value,
                    IsSyncFromInputInvoice = (int)invoiceTypeCombobox.SelectedValue == 1,
                    IsPaymentOrder = uynhiemCheckbox.Checked,
                    OrganizationId = "6389c0439559de782733c323",
                    SubscriberId = "asp-0a9ccab75ad106d744310c2f"
                };

                RequestSyncTaxAuthorityToCompare requestSyncCompare = new RequestSyncTaxAuthorityToCompare
                {
                    OrganizationId = "6389c0439559de782733c323",
                    SubscriberId = "asp-0a9ccab75ad106d744310c2f",
                    IsPaymentOrder = uynhiemCheckbox.Checked,
                    StartDate = fromDate.Value,
                    EndDate = toDate.Value,
                    SyncFromTypeInvoice = 0
                };

                //var invoiceListResult = await crawler.SyncInvoiceInRange(requestSyncTax);
                var invoiceListResult = await crawler.SyncInvoiceInRangeToCompare(requestSyncCompare);

                //lstInvoice.DataSource = null;
                //lstInvoice.DataSource = invoiceListResult.Select(x => new
                //{

                //    TemplateNo = x.TemplateNo,
                //    Series = x.Series,
                //    InvoiceNo = x.InvoiceNo,
                //    InvoiceDate = x.InvoiceDate,
                //    SellerTaxCode = x.SellerTaxCode,
                //    StatusInvoice = x.InfoND123.Status ?? x.StatusInvoice,
                //    ProcessingStatus = x.ProcessingStatus
                //}).ToList();

                //totalRecord.Text = $"Total: {invoiceListResult.Count}";
            }
            finally
            {
                stopwatch.Stop();
                double executionTimeInSeconds = (double)stopwatch.ElapsedMilliseconds / 1000;
                timeExecute.Text = $"Execute time: {executionTimeInSeconds}s";
                button1.Enabled = true;
            }

            ////textInvoicesList.Text = JsonConvert.SerializeObject(lstInvoiceDownload);
            ////var lstInvoiceDetails = await crawler.GetInvoiceInfoAsyc(lstInvoiceDownload, progressBarManager);
            ////var lstXmlByteAsync = await crawler.DownloadXmlAsync(lstInvoiceDownload, progressBarManager);

            //await SendXmlToAnotherApiAsync(lstXmlByteAsync);
        }

        private async void BtnGetCaptchaClick(object sender, EventArgs e)
        {
            btnGetCaptcha.Enabled = false;
            try
            {
                var crawler = new EInvoiceCrawler();
                var captcha = await crawler.GetCaptchaSvgFromWebsiteHDDT();
                MisaDecaptcha misaDecaptcha = new MisaDecaptcha();
                captchaKey.Text = captcha.Key;
                byte[] jpegBytes = misaDecaptcha.ConvertSvgToJpegByte(captcha.SvgContent);
                using (MemoryStream memoryStream = new MemoryStream(jpegBytes))
                {
                    Image captchaImage = Image.FromStream(memoryStream);
                    captchaImageBox.Image = captchaImage;
                }
                captchaText.Text = captcha.Content;
            }
            finally
            {
                btnGetCaptcha.Enabled = true;
            }
        }

        private void LstInvoice_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex >= 0) // Make sure a valid row index is clicked
            //{
            //    var selectedRow = lstInvoice.Rows[e.RowIndex];
            //    mstnb.Text = selectedRow.Cells["MSTNBan"].Value.ToString();
            //    kh.Text = selectedRow.Cells["Series"].Value.ToString();
            //    sohoadon.Text = selectedRow.Cells["InvoiceNo"].Value.ToString();
            //    khmshd.Text = selectedRow.Cells["TemplateNo"].Value.ToString();
            //}
        }

        private void ContextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (e.ClickedItem.Text)
            {
                case "Thoát":
                    notifyIcon1.Visible = false;
                    contextMenuStrip1.Hide();
                    isClosingFromForm = true;
                    Application.Exit();
                    break;
            }
        }

        private void NotifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Show();
                this.ShowInTaskbar = true;
                this.Visible = true;
                this.WindowState = FormWindowState.Normal;
                contextMenuStrip1.Hide();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing && !isClosingFromForm)
            {
                e.Cancel = true;
                this.WindowState = FormWindowState.Minimized;
                this.ShowInTaskbar = false; // Ẩn cửa sổ khỏi taskbar
                this.Visible = false; // Ẩn cửa sổ ban đầu
            }
        }

        private void Form1_Closed(object sender, FormClosedEventArgs e)
        {
            notifyIcon1.Dispose();
        }
    }
}
