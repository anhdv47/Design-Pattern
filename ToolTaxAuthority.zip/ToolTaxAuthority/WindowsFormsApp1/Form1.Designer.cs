﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.fromDate = new System.Windows.Forms.DateTimePicker();
            this.toDate = new System.Windows.Forms.DateTimePicker();
            this.fromDateLabel = new System.Windows.Forms.Label();
            this.toDateLabel = new System.Windows.Forms.Label();
            this.sohoadon = new System.Windows.Forms.TextBox();
            this.lstInvoice = new System.Windows.Forms.DataGridView();
            this.btnGetCaptcha = new System.Windows.Forms.Button();
            this.captchaKey = new System.Windows.Forms.TextBox();
            this.captchaText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.captchaImageBox = new System.Windows.Forms.PictureBox();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.labelUsername = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tthaiCombobox = new System.Windows.Forms.ComboBox();
            this.ttxlyCombobox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.uynhiemCheckbox = new System.Windows.Forms.CheckBox();
            this.invoiceTypeCombobox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.totalRecord = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.progressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.timeExecute = new System.Windows.Forms.ToolStripStatusLabel();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.cboUsername = new System.Windows.Forms.ComboBox();
            this.xApiKey = new System.Windows.Forms.Label();
            this.txtBoxXApiKey = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProjectName = new System.Windows.Forms.TextBox();
            this.cboApiKey = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.lstInvoice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.captchaImageBox)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(216, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 21);
            this.button1.TabIndex = 0;
            this.button1.Text = "Lấy hóa đơn";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.BtnGetInvoicesInRangeClick);
            // 
            // fromDate
            // 
            this.fromDate.CustomFormat = "dd/MM/yyyy";
            this.fromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.fromDate.Location = new System.Drawing.Point(216, 30);
            this.fromDate.Name = "fromDate";
            this.fromDate.Size = new System.Drawing.Size(98, 20);
            this.fromDate.TabIndex = 1;
            this.fromDate.ValueChanged += new System.EventHandler(this.fromDate_ValueChanged);
            // 
            // toDate
            // 
            this.toDate.CustomFormat = "dd/MM/yyyy";
            this.toDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.toDate.Location = new System.Drawing.Point(320, 31);
            this.toDate.Name = "toDate";
            this.toDate.Size = new System.Drawing.Size(105, 20);
            this.toDate.TabIndex = 2;
            // 
            // fromDateLabel
            // 
            this.fromDateLabel.AutoSize = true;
            this.fromDateLabel.Location = new System.Drawing.Point(213, 14);
            this.fromDateLabel.Name = "fromDateLabel";
            this.fromDateLabel.Size = new System.Drawing.Size(46, 13);
            this.fromDateLabel.TabIndex = 3;
            this.fromDateLabel.Text = "Từ ngày";
            // 
            // toDateLabel
            // 
            this.toDateLabel.AutoSize = true;
            this.toDateLabel.Location = new System.Drawing.Point(317, 13);
            this.toDateLabel.Name = "toDateLabel";
            this.toDateLabel.Size = new System.Drawing.Size(53, 13);
            this.toDateLabel.TabIndex = 4;
            this.toDateLabel.Text = "Đến ngày";
            // 
            // sohoadon
            // 
            this.sohoadon.Location = new System.Drawing.Point(423, 99);
            this.sohoadon.Name = "sohoadon";
            this.sohoadon.Size = new System.Drawing.Size(127, 20);
            this.sohoadon.TabIndex = 8;
            this.sohoadon.TextChanged += new System.EventHandler(this.sohoadon_TextChanged);
            // 
            // lstInvoice
            // 
            this.lstInvoice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lstInvoice.Location = new System.Drawing.Point(18, 124);
            this.lstInvoice.Name = "lstInvoice";
            this.lstInvoice.Size = new System.Drawing.Size(532, 294);
            this.lstInvoice.TabIndex = 15;
            this.lstInvoice.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.LstInvoice_CellClick);
            // 
            // btnGetCaptcha
            // 
            this.btnGetCaptcha.Location = new System.Drawing.Point(644, 214);
            this.btnGetCaptcha.Name = "btnGetCaptcha";
            this.btnGetCaptcha.Size = new System.Drawing.Size(75, 23);
            this.btnGetCaptcha.TabIndex = 18;
            this.btnGetCaptcha.Text = "Lấy Captcha";
            this.btnGetCaptcha.UseVisualStyleBackColor = true;
            this.btnGetCaptcha.Click += new System.EventHandler(this.BtnGetCaptchaClick);
            // 
            // captchaKey
            // 
            this.captchaKey.Location = new System.Drawing.Point(644, 163);
            this.captchaKey.Name = "captchaKey";
            this.captchaKey.Size = new System.Drawing.Size(169, 20);
            this.captchaKey.TabIndex = 19;
            // 
            // captchaText
            // 
            this.captchaText.Location = new System.Drawing.Point(644, 188);
            this.captchaText.Name = "captchaText";
            this.captchaText.Size = new System.Drawing.Size(169, 20);
            this.captchaText.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(563, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Captcha Key";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(563, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Captcha Text";
            // 
            // captchaImageBox
            // 
            this.captchaImageBox.Location = new System.Drawing.Point(566, 29);
            this.captchaImageBox.Name = "captchaImageBox";
            this.captchaImageBox.Size = new System.Drawing.Size(247, 50);
            this.captchaImageBox.TabIndex = 23;
            this.captchaImageBox.TabStop = false;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Location = new System.Drawing.Point(450, 73);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(100, 20);
            this.textBoxPassword.TabIndex = 25;
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Location = new System.Drawing.Point(448, 14);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(55, 13);
            this.labelUsername.TabIndex = 26;
            this.labelUsername.Text = "Username";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(448, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "Password";
            // 
            // tthaiCombobox
            // 
            this.tthaiCombobox.FormattingEnabled = true;
            this.tthaiCombobox.Location = new System.Drawing.Point(18, 30);
            this.tthaiCombobox.Name = "tthaiCombobox";
            this.tthaiCombobox.Size = new System.Drawing.Size(192, 21);
            this.tthaiCombobox.TabIndex = 28;
            // 
            // ttxlyCombobox
            // 
            this.ttxlyCombobox.FormattingEnabled = true;
            this.ttxlyCombobox.Location = new System.Drawing.Point(18, 70);
            this.ttxlyCombobox.Name = "ttxlyCombobox";
            this.ttxlyCombobox.Size = new System.Drawing.Size(192, 21);
            this.ttxlyCombobox.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "Trạng thái hóa đơn";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "Kết quả kiểm tra";
            // 
            // uynhiemCheckbox
            // 
            this.uynhiemCheckbox.AutoSize = true;
            this.uynhiemCheckbox.Location = new System.Drawing.Point(19, 97);
            this.uynhiemCheckbox.Name = "uynhiemCheckbox";
            this.uynhiemCheckbox.Size = new System.Drawing.Size(113, 17);
            this.uynhiemCheckbox.TabIndex = 32;
            this.uynhiemCheckbox.Text = "Hóa đơn ủy nhiệm";
            this.uynhiemCheckbox.UseVisualStyleBackColor = true;
            // 
            // invoiceTypeCombobox
            // 
            this.invoiceTypeCombobox.FormattingEnabled = true;
            this.invoiceTypeCombobox.Location = new System.Drawing.Point(216, 70);
            this.invoiceTypeCombobox.Name = "invoiceTypeCombobox";
            this.invoiceTypeCombobox.Size = new System.Drawing.Size(209, 21);
            this.invoiceTypeCombobox.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(213, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "Tra cứu theo";
            // 
            // totalRecord
            // 
            this.totalRecord.AutoSize = true;
            this.totalRecord.Location = new System.Drawing.Point(356, 428);
            this.totalRecord.Name = "totalRecord";
            this.totalRecord.Size = new System.Drawing.Size(37, 13);
            this.totalRecord.TabIndex = 35;
            this.totalRecord.Text = "Total: ";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.progressBar,
            this.timeExecute});
            this.statusStrip1.Location = new System.Drawing.Point(0, 452);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(825, 22);
            this.statusStrip1.TabIndex = 37;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // progressBar
            // 
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(100, 16);
            // 
            // timeExecute
            // 
            this.timeExecute.Name = "timeExecute";
            this.timeExecute.Size = new System.Drawing.Size(78, 17);
            this.timeExecute.Text = "Execute time:";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "ToolTaxAuthority";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.NotifyIcon1_MouseClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripQuit});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(105, 26);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ContextMenuStrip1_ItemClicked);
            // 
            // toolStripQuit
            // 
            this.toolStripQuit.Name = "toolStripQuit";
            this.toolStripQuit.Size = new System.Drawing.Size(104, 22);
            this.toolStripQuit.Text = "Thoát";
            // 
            // cboUsername
            // 
            this.cboUsername.FormattingEnabled = true;
            this.cboUsername.Location = new System.Drawing.Point(450, 29);
            this.cboUsername.Name = "cboUsername";
            this.cboUsername.Size = new System.Drawing.Size(100, 21);
            this.cboUsername.TabIndex = 45;
            // 
            // xApiKey
            // 
            this.xApiKey.AutoSize = true;
            this.xApiKey.Location = new System.Drawing.Point(563, 117);
            this.xApiKey.Name = "xApiKey";
            this.xApiKey.Size = new System.Drawing.Size(58, 13);
            this.xApiKey.TabIndex = 46;
            this.xApiKey.Text = "X-API-KEY";
            // 
            // txtBoxXApiKey
            // 
            this.txtBoxXApiKey.Location = new System.Drawing.Point(644, 114);
            this.txtBoxXApiKey.Name = "txtBoxXApiKey";
            this.txtBoxXApiKey.Size = new System.Drawing.Size(169, 20);
            this.txtBoxXApiKey.TabIndex = 47;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(563, 92);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 48;
            this.label11.Text = "DECAPT-API";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(563, 139);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 50;
            this.label12.Text = "Project";
            // 
            // txtProjectName
            // 
            this.txtProjectName.Location = new System.Drawing.Point(644, 137);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(169, 20);
            this.txtProjectName.TabIndex = 51;
            // 
            // cboApiKey
            // 
            this.cboApiKey.FormattingEnabled = true;
            this.cboApiKey.Location = new System.Drawing.Point(644, 87);
            this.cboApiKey.Name = "cboApiKey";
            this.cboApiKey.Size = new System.Drawing.Size(169, 21);
            this.cboApiKey.TabIndex = 52;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(376, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Search";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 474);
            this.Controls.Add(this.cboApiKey);
            this.Controls.Add(this.txtProjectName);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtBoxXApiKey);
            this.Controls.Add(this.xApiKey);
            this.Controls.Add(this.cboUsername);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.totalRecord);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.invoiceTypeCombobox);
            this.Controls.Add(this.uynhiemCheckbox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ttxlyCombobox);
            this.Controls.Add(this.tthaiCombobox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelUsername);
            this.Controls.Add(this.textBoxPassword);
            this.Controls.Add(this.captchaImageBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.captchaText);
            this.Controls.Add(this.captchaKey);
            this.Controls.Add(this.btnGetCaptcha);
            this.Controls.Add(this.lstInvoice);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.sohoadon);
            this.Controls.Add(this.toDateLabel);
            this.Controls.Add(this.fromDateLabel);
            this.Controls.Add(this.toDate);
            this.Controls.Add(this.fromDate);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "ToolTaxAuthority";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_Closed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lstInvoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.captchaImageBox)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker fromDate;
        private System.Windows.Forms.DateTimePicker toDate;
        private System.Windows.Forms.Label fromDateLabel;
        private System.Windows.Forms.Label toDateLabel;
        private System.Windows.Forms.TextBox sohoadon;
        private System.Windows.Forms.DataGridView lstInvoice;
        private System.Windows.Forms.Button btnGetCaptcha;
        private System.Windows.Forms.TextBox captchaKey;
        private System.Windows.Forms.TextBox captchaText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox captchaImageBox;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox tthaiCombobox;
        private System.Windows.Forms.ComboBox ttxlyCombobox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox uynhiemCheckbox;
        private System.Windows.Forms.ComboBox invoiceTypeCombobox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label totalRecord;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar progressBar;
        private System.Windows.Forms.ToolStripStatusLabel timeExecute;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripQuit;
        private System.Windows.Forms.ComboBox cboUsername;
        private System.Windows.Forms.Label xApiKey;
        private System.Windows.Forms.TextBox txtBoxXApiKey;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProjectName;
        private System.Windows.Forms.ComboBox cboApiKey;
        private System.Windows.Forms.Label label3;
    }
}

