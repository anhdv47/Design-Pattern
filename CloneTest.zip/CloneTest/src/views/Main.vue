<template>
    <v-app class="main-app">
        <div class="header">
            <Header />
        </div>
        <div class="main-body">
            <router-view />
        </div>
    </v-app>
</template>

<script setup>
    import Header from '@/components/Header.vue';
</script>

<style lang="scss" scoped>
    .main-app {
        .header {
            height: 64px;
        }
        .main-body {
            // height: calc(100vh - 64px);
            flex: 1;
        }
    }
</style>
