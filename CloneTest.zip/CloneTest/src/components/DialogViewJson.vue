<template>
    <div ref="modalWrapRef" :class="class" class="v-dialog-modal">
        <v-card>
            <v-card-text>
                <JsonViewer :value="props.data" copyable sort theme="light" class="json-viewer" />
            </v-card-text>
        </v-card>
    </div>
</template>

<script setup>
    import { onMounted, ref, defineProps } from 'vue';
    const props = defineProps({
        data: {
            type: Object,
        },

        class: {
            type: String,
        },
    });
</script>

<style lang="scss" scoped>
    .v-dialog-modal {
        width: 90%;
        height: 85%;
        overflow: auto;
    }
</style>
