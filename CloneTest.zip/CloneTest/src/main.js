import { createApp } from 'vue';
import App from './App.vue';
import { setupRouter } from './router';
import { registerPlugins } from '@/plugins';
import { setupStore } from '@/store';
import './index.css';

const app = createApp(App);

function setupPlugins() {
    registerPlugins(app);
}
async function setupApp() {
    setupStore(app);
    setupRouter(app);
    app.mount('#app');
}

setupPlugins();
setupApp();
