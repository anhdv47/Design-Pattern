<script setup>
    import Main from '@/views/Main.vue';
    import { container } from 'jenesius-vue-modal';
    const WidgetModalContainer = container;
</script>

<template>
    <Main />
    <WidgetModalContainer />
</template>

<style scoped></style>
