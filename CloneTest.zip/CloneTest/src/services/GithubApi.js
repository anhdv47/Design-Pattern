import { Octokit } from 'octokit';
import Storage from '../utils/Storage';
import CommonFunction from '@/utils/CommonFunction';
import { useUserStore } from '@/store/modules/user';

export default new (class GithubApi {
    constructor() {}

    getOctokit(token = null) {
        if (!token) token = CommonFunction.getToken();
        const octokit = new Octokit({
            auth: token,
        });
        octokit.hook.wrap('request', async (request, options) => {
            const response = await request(options);
            if (response.status === 401) {
                useUserStore().resetToken();
                return Promise.reject('Invalid token');
            }
            if (response.headers['x-ratelimit-remaining'] && useUserStore().rateLimit !== null) {
                useUserStore().rateLimit['rate'] = {
                    remaining: response.headers['x-ratelimit-remaining'],
                    reset: response.headers['x-ratelimit-reset'],
                    used: response.headers['x-ratelimit-used'],
                    limit: response.headers['x-ratelimit-limit'],
                };
            }
            return response;
        });
        return octokit;
    }

    async getCurrentUser(token) {
        return await this.getOctokit(token).rest.users.getAuthenticated();
    }

    /**
     * @description: Lấy thông tin các repo của user
     * @param: {any}
     * Author: AnhDV 24/02/2024
     */
    async getAllRepositoryOfUser() {
        return await this.getOctokit().request('GET /users/repos');
    }

    async getFileContent(repositoryName, fileName) {
        return await this.getOctokit().rest.repos.getContent({
            owner: useUserStore().userInfo.login,
            repo: repositoryName,
            path: fileName,
        });
    }
})();
